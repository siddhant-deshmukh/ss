#!/usr/bin/env python3

from itertools import count
from lib2to3.pgen2.token import RPAR
from tabnanny import check
import rospy
from std_msgs.msg import UInt8
from geometry_msgs.msg import *
from mavros_msgs.msg import *
from mavros_msgs.srv import *
from gazebo_ros_link_attacher.srv import *
from rospy.impl.transport import BIDIRECTIONAL
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError
import cv2
import numpy as np
import threading


#this will hold methods needed to operate drone in offboard
#like arming, changing drone mode, activate gripper, setting parameters
class offboard_control:
    def __init__(self):
        # Initialise rosnode
        rospy.init_node('strawberry_stacker', anonymous=True)
        
    def setArm(self, value=True,droneName='edrone1'):
        # Calling to /mavros/cmd/arming to arm the drone and print fail message on failure
        rospy.wait_for_service(droneName+'/mavros/cmd/arming')  # Waiting untill the service starts 
        try:
            armService = rospy.ServiceProxy(droneName+'/mavros/cmd/arming', mavros_msgs.srv.CommandBool) # Creating a proxy service for the rosservice named /mavros/cmd/arming for arming the drone 
            result=armService(value)
            print(result)
        except rospy.ServiceException as e:
            print ("Service arming call failed: %s"%e)

        # Similarly delacre other service proxies 
    def offboard_set_mode(self,droneName='edrone1'):
        # Call /mavros/set_mode to set the mode the drone to OFFBOARD
        # and print fail message on failure
        rospy.wait_for_service(droneName+'/mavros/set_mode')
        try:
            setMode=rospy.ServiceProxy(droneName+'/mavros/set_mode',mavros_msgs.srv.SetMode)
            result=setMode(custom_mode='OFFBOARD')
            #print("set mode to offboard")
            print(result)
        except rospy.ServiceException as e:
            print ("Service offvoard set_mode call failed: %s"%e)
                
    def setAutoLandMode(self,droneName='edrone1'):
        rospy.wait_for_service(droneName+'/mavros/set_mode')
        try:
            flightModeService = rospy.ServiceProxy(droneName+'/mavros/set_mode', mavros_msgs.srv.SetMode)
            flightModeService(custom_mode='AUTO.LAND')
        except rospy.ServiceException as e:
            print("service set_mode call failed: %s. Autoland Mode could not be set."%e)

    def set_parameter(self,paramId='COM_RCL_EXCEPT',set_param_value_integer=2,set_param_value_real=2.0,droneName='edrone1'):
        rospy.wait_for_service(droneName+'/mavros/param/set')
        try:

            setParams=rospy.ServiceProxy(droneName+'/mavros/param/set',mavros_msgs.srv.ParamSet)
            paramValue= ParamValue()
            paramValue.real=set_param_value_real
            response=setParams(param_id=paramId,value=paramValue)
            #print("Done here!!")
            #print("setting parameter", paramId , response.success , response.value.real)
        except rospy.ServiceException as e:
            print("Service  set_Parameters call failed: %s"%e)
    def activateGripper(self, setValue=True,droneName='edrone1'):
        print("trying to activate Gripper")
        rospy.wait_for_service(droneName+"/activate_gripper")
        try:
            gripper = rospy.ServiceProxy(droneName+'/activate_gripper', Gripper )
            result = gripper(activate_gripper=setValue)
            #print("result of activaGripper : " , result)
            return result
        except rospy.ServiceException as e:
            print("service activaGripper call failed: %s. Autoland Mode could not be set."%e)
   
#this will hold current state of drone
#like it's position, velocity, is gripper ready, is aruco visible
class stateMoniter:
    def __init__(self , droneName, homepose):
        self.state = State()
        # Instantiate a setpoints message
        self.positionX=0
        self.positionY=0
        self.positionZ=0

        self.gX = 0              #co-ordinates of drone in global frame
        self.gY = 0

        self.droneName = droneName               #edrone/edrone1
        self.homepose = homepose                #home position of drone in global frame

        self.velX=0
        self.velY=0
        self.velZ=0                        #velocity of drone

        self.isGripperCheck=False
        self.img = np.empty([]) # This will contain your image frame from camera
        self.bridge = CvBridge()

        self.picture_count=0
        self.isArucoMarkerVisible=False         #this shows wither Aruco Marker is their or not
        
        #this will save the errors
        self.pixelErrorX=0               #x distance between the center of caemra and center of AruCo
        self.pixelErrorY=0               #y distance between the center of caemra and center of AruCo
        self.sideOfSquare =1                  #x distance between two corners of AruCo 1st and 4th

        self.moreThanOneAruco = False
        self.extended_state = ExtendedState()

        topic_name=['ext_state', 'local_pos','state','mission_wp'] #'alt'
        self.sub_topics_ready = {}
        for _ in topic_name:
            self.sub_topics_ready[_] = False

        self.setToLandOnAruco = False
        self.arucoColorId = 0

    def stateCb(self, msg):
        # Callback function for topic /mavros/state
        self.state = msg

        if not self.sub_topics_ready['state'] : #and msg.connected
            self.sub_topics_ready['state'] = True
    def setPositionCallback(self ,data):
        #to keep track of drone position
        self.positionX=data.pose.position.x 
        self.positionY=data.pose.position.y 
        self.positionZ=data.pose.position.z

        self.gX=data.pose.position.x + self.homepose[0]
        self.gY=data.pose.position.y + self.homepose[1]

        if not self.sub_topics_ready['local_pos']:
            self.sub_topics_ready['local_pos'] = True
    def setVelocityCallback(self,data):
        #to keep tarck of drone velocity
        self.velX=data.twist.linear.x 
        self.velY=data.twist.linear.y 
        self.velZ=data.twist.linear.z
    def gripperCheck(self, data):
        #to check if gripper is ready to activate or not
        if data.data == 'True':
            self.isGripperCheck=True
        else:
            self.isGripperCheck=False
    def extended_state_callback(self, data):
        self.extended_state = data

        if not self.sub_topics_ready['ext_state']:
            self.sub_topics_ready['ext_state'] = True
    def mission_wp_callback(self,data):                   #this is only to check if drone is ready to go in offboard mode
        if not self.sub_topics_ready['mission_wp']:
            self.sub_topics_ready['mission_wp'] = True
    
    def removeBorderAruco(self,corners,ids):
        if len(corners)==0 :
            return corners,ids
        try:
            if ids == None:
                print("Special :",corners)
                return corners,ids
            else:
                co = []
                id = []
                count = 0
                for markerCorner in corners:
                    currXY=(int((markerCorner[0][0][0] + markerCorner[0][2][0])//2),int((markerCorner[0][0][1] + markerCorner[0][2][1])//2))
                    if currXY[1] > 60 and currXY[1] < 340:
                        co.append(markerCorner)
                        id.append(ids[count])
                    count+=1    
                return co,id
        except:
            co = []
            id = []
            count = 0
            for markerCorner in corners:
                currXY=(int((markerCorner[0][0][0] + markerCorner[0][2][0])//2),int((markerCorner[0][0][1] + markerCorner[0][2][1])//2))
                if currXY[1] > 60 and currXY[1] < 340:
                    co.append(markerCorner)
                    id.append(ids[count])
                count+=1    
            return co,id

    def imageCallBack(self,img):
        try:
            img = self.bridge.imgmsg_to_cv2(img, "bgr8")               # Converting the image to OpenCV standard image
            
            self.picture_count=0
            self.isArucoMarkerVisible=False         #this shows wither Aruco Marker is their or not
            
            #this will save the errors
            self.pixelErrorX=0               #x distance between the center of caemra and center of AruCo
            self.pixelErrorY=0               #y distance between the center of caemra and center of AruCo
            self.sideOfSquare =1                  #x distance between two corners of AruCo 1st and 4th
            
            #detecting aruco and its corners
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            aruco_dict = cv2.aruco.Dictionary_get(cv2.aruco.DICT_5X5_250)
            parameters = cv2.aruco.DetectorParameters_create()
            corners, ids, _ = cv2.aruco.detectMarkers(gray, aruco_dict, parameters = parameters)
            
            if len(corners)==0 :    
                self.isArucoMarkerVisible=False
            else:  
                corners,ids=self.removeBorderAruco(corners,ids)
                if len(corners) != 0:
                    self.isArucoMarkerVisible=True

            height, width, _ = img.shape
            if  len(corners)!=0 :
                if len(ids) == 1:
                    self.moreThanOneAruco=False

                    markerCorner=corners[0]
                    cXY=(int((markerCorner[0][0][0] + markerCorner[0][2][0])//2),int((markerCorner[0][0][1] + markerCorner[0][2][1])//2))
                    
                    #how many pixels are their in side of Aruco 
                    #this will tell us how close drone is frome Aruco in height
                    self.sideOfSquare=abs(int(((markerCorner[0][3][0] - markerCorner[0][0][0])**2+(markerCorner[0][3][1] - markerCorner[0][0][1])**2)**0.5))
                    
                    self.pixelErrorX=(cXY[0]-width//2)
                    if self.positionZ < 3.2 :
                        self.pixelErrorY=(height//2)-(cXY[1]- (1.25*self.sideOfSquare) - 13.5) #for default SDF file
                    else:
                        self.pixelErrorY=height//2 - cXY[1]
                    #because camera is not at center position of drone self.pixelError is modified
                    self.arucoColorId=ids[0][0]
                else:
                    self.moreThanOneAruco=True

                    minDis = 400
                    currDis = 400
                    cXY = (200,200)
                    currXY = (200,200)
                    ss=10
                    index=0
                    count=0
                    for markerCorner in corners:
                        currXY=(int((markerCorner[0][0][0] + markerCorner[0][2][0])//2),int((markerCorner[0][0][1] + markerCorner[0][2][1])//2))
                        currDis = ((currXY[0]-200)**2 + (currXY[1]-200)**2)**0.5
                        if currDis < minDis:
                            minDis = currDis
                            cXY=currXY
                            index =count
                        count+=1
                    
                    #how many pixels are their in side of Aruco 
                    #this will tell us how close drone is frome Aruco in height
                    markerCorner = corners[index]
                    self.arucoColorId=ids[index][0]
                    self.sideOfSquare=abs(int(((markerCorner[0][3][0] - markerCorner[0][0][0])**2+(markerCorner[0][3][1] - markerCorner[0][0][1])**2)**0.5))
                    self.pixelErrorX=(cXY[0]-width//2)
                    if self.positionZ < 3 :
                        self.pixelErrorY=(height//2)-(cXY[1]- (1.25*self.sideOfSquare) - 13.5) #for default SDF file
                    else:
                        self.pixelErrorY=height//2  - cXY[1]


        except CvBridgeError as e:
            print(e)
            return

#this class will contain all methods to control drone
class single_drone_control:
    def __init__(self, stateMt, droneName='edrone1',homepose=(-1,1) , height=0,ofb_ctl=None):
        #this function can be used to arm the drone or setting mode to OFFBOARD mode

        self.droneName=droneName
        self.cameraName=droneName
        self.ofb_ctl=ofb_ctl
        self.stateMt=stateMt
        self.homepose=homepose

        self.baseHeight  = height
        self.isLandingOnBox = False
        self.firstDetected = None

        self.anotherDrones = []
        self.ArucoId = 0

        self.isRed=False
        self.noDown=False
        self.redArucoSpots=[]
        self.caughtAruco=False

        ll= np.empty(16, dtype=object)
        for _ in range(16):
            ll[_] = list()
        self.boycottSpots = ll[:]

        #publisher
        self.local_pos_pub = rospy.Publisher(self.droneName+'/mavros/setpoint_position/local', PoseStamped, queue_size=10)
        self.local_vel_pub = rospy.Publisher(self.droneName+'/mavros/setpoint_velocity/cmd_vel_unstamped',Twist, queue_size=10)
        #subscriber
        rospy.Subscriber(self.droneName+"/mavros/state",State, self.stateMt.stateCb)
        rospy.Subscriber(self.droneName+"/mavros/local_position/pose", PoseStamped, self.stateMt.setPositionCallback)
        rospy.Subscriber(self.droneName+"/gripper_check",std_msgs.msg.String , self.stateMt.gripperCheck )
        
        rospy.Subscriber(self.cameraName+"/camera/image_raw",Image,self.stateMt.imageCallBack)
        rospy.Subscriber(self.droneName+"/mavros/local_position/velocity_local",TwistStamped,self.stateMt.setVelocityCallback)
        rospy.Subscriber(self.droneName+'/mavros/extended_state',ExtendedState, self.stateMt.extended_state_callback)
        
        rospy.Subscriber(self.droneName+'/mavros/mission/waypoints', WaypointList, self.stateMt.mission_wp_callback)

        #will wait for topics to be ready
        if self.wait_for_topics(60):
            print("Ready to fly!!" , self.droneName)
        else:
            print("Failed to fly!!!" ,self.droneName)
        
        #setting parameter
        self.ofb_ctl.set_parameter('COM_DISARM_LAND',set_param_value_real= 5.0,droneName=self.droneName)
        self.ofb_ctl.set_parameter('MPC_XY_VEL_MAX',set_param_value_real=5.0,droneName=self.droneName)  #to control maximum automatic speed of Drone                                                                  #will be good if kept less than 5
        self.ofb_ctl.set_parameter('MPC_LAND_ALT1',set_param_value_real=3.0,droneName=self.droneName)
        self.ofb_ctl.set_parameter('MPC_LAND_ALT2',set_param_value_real=1.2,droneName=self.droneName)
    
    #to arm drone if it is not arm or to go in offboard mode if it is not in offboard mode
    def wait_for_topics(self, timeout):
        
        rospy.loginfo("waiting for subscribed topics to be ready")
        loop_freq = 5  # Hz
        rate = rospy.Rate(loop_freq)
        simulation_ready = False
        for i in range(timeout * loop_freq):
            if all(value for value in self.stateMt.sub_topics_ready.values()):
                simulation_ready = True
                break
            try:
                rate.sleep()
            except rospy.ROSException as e:
                self.fail(e)
        return simulation_ready

    #this will arm drone if it is not armed and set mode to offboard if it is not in offboard mode
    def armingDrone(self):
        pos =PoseStamped()
        pos.pose.position.x = 0
        pos.pose.position.y = 0
        pos.pose.position.z = 0

        rate = rospy.Rate(20.0)
        if self.stateMt.state.mode != "OFFBOARD":
            for i in range(100):
                self.local_pos_pub.publish(pos)
                rate.sleep()
        while not self.stateMt.state.armed:               #checking if it is already armed or not
            self.ofb_ctl.setArm(droneName=self.droneName)
            rate.sleep()
            print("Arming!!")
        while not self.stateMt.state.mode=="OFFBOARD":
            self.ofb_ctl.offboard_set_mode(droneName=self.droneName)
            rate.sleep()
            print ("OFFBOARD mode being activated")
    
    def setAnotherDrone(self, object):
        self.anotherDrones=object
    #to stop the Drone it will reduce drone x y speed to 0
    def stopTheDrone(self):
        vel=Twist()
        vel.linear.x = 0
        vel.linear.y = 0
        vel.linear.z = 0
        rate = rospy.Rate(20.0)
        if self.checkIfBoycotted():
            self.stateMt.isArucoMarkerVisible=False
            rate.sleep()
            return
        self.local_vel_pub.publish(vel)
        while not rospy.is_shutdown():
            rate.sleep()
            if abs(self.stateMt.velX)<0.05 and abs(self.stateMt.velY)<0.05:
                break
        return
    
    #works for local-coordinates only 
    def goToPoint(self, target, absoluteErrorMargin=(0.2,0.2,0.2) , landOnArucoBool=False ):
        
        tarX,tarY,tarZ=target
        pos=PoseStamped()
        rate = rospy.Rate(20.0)
        rate2=rospy.Rate(50.0)
        pos.pose.position.x, pos.pose.position.y, pos.pose.position.z  = tarX,tarY,tarZ
        currX,currY,currZ=self.stateMt.positionX,self.stateMt.positionY,self.stateMt.positionZ
        
        self.local_pos_pub.publish(pos)
        #rate.sleep()
        abs1,abs2,abs3=absoluteErrorMargin
        #waiting till drone goes in allowable range
        while  not rospy.is_shutdown():
            #if ArucoDetected then this landOnAruco function will be called and we will firstly land on the box
            if not self.stateMt.state.armed or not self.stateMt.state.mode=="OFFBOARD":
                self.armingDrone()
            currX,currY,currZ=self.stateMt.positionX,self.stateMt.positionY,self.stateMt.positionZ
            if (abs(tarX-currX) < abs1 and abs(tarY-currY) < abs2 and abs(tarZ-currZ)<abs3):
                break
            rate2.sleep()
        rate.sleep() 
    
    def setPointGlobal(self,target, absoluteErrorMargin=(0.2,0.2,0.2) ,speed=None, landOnArucoBool=False):
        if speed!= None:
            self.ofb_ctl.set_parameter('MPC_XY_VEL_MAX',set_param_value_real=speed,droneName=self.droneName)
        else:
            if abs(target[0]-self.stateMt.gX) > 30 or abs(target[1]-self.stateMt.gY) > 30 :
                self.ofb_ctl.set_parameter('MPC_XY_VEL_MAX',set_param_value_real=10.0,droneName=self.droneName)
            else:
                self.ofb_ctl.set_parameter('MPC_XY_VEL_MAX',set_param_value_real=5.0,droneName=self.droneName)
            
        tarX=target[0]-self.homepose[0] 
        tarY=target[1]-self.homepose[1]
        tarZ=target[2]
        print(self.droneName," target is : ",  target, "\tcurrent is :",self.stateMt.gX,self.stateMt.gY,self.stateMt.positionZ)
        self.goToPoint((tarX,tarY,tarZ), absoluteErrorMargin,landOnArucoBool)     #+self.baseHeight
    
    def handleBoycottBoxes(self,gX,gY):
        print("Boycotted spots at  :" , gY )
        if gY < 1:
            rowN=1
        elif gY > 61:
            rowN=15
        else:
            if abs(gY- (((gY-1)//4)*4 +1)) > abs(gY- (((gY-1)//4+1)*4 +1)):
                rowN= (gY-1)//4
            else:
                rowN=  (gY-1)//4+1
        rowN=int(rowN)
        print("\t", self.boycottSpots[rowN])
        for _ in self.boycottSpots[rowN]:
            if abs(_-gX) < 3:
                return
        self.boycottSpots[rowN].append(gX)
        print("Boycotted spots after at  :" , rowN , "\t", self.boycottSpots[rowN])

    def onSpot(self):
        rate2=rospy.Rate(15.0)
        rate = rospy.Rate(20.0)
        #-------------------------------------------    onSpot ---------------------------------------------------------
        print( self.droneName,"on spot activated!!",self.stateMt.gX,self.stateMt.gY,self.stateMt.positionZ )

        if self.checkIfBoycotted():
            self.stateMt.isArucoMarkerVisible=False
            rate2.sleep()
            return False
        
        gainX,gainY=0,0
        errorX,errorY=0,0
        stopX,stopY = False,False
        vel = Twist()
        r2 = rospy.Rate(15)
        
        currZ = self.stateMt.positionZ
        self.stopTheDrone()

        if not self.stateMt.isArucoMarkerVisible:
            ccc = 0
            self.goToPoint((self.stateMt.positionX,self.stateMt.positionY,3+self.baseHeight))
            for __ in range(15):
                rate2.sleep()
                if self.stateMt.isArucoMarkerVisible:
                    self.firstDetected=self.stateMt.positionX,self.stateMt.positionY,self.stateMt.positionZ
                    break
                ccc+=1
            if ccc > 8:
                print("trying to fix it" , self.droneName)
                if self.checkIfBoycotted(self.firstDetected[0],self.firstDetected[1]):
                    self.stateMt.isArucoMarkerVisible=False
                    rate2.sleep()
                    return False
                self.goToPoint(self.firstDetected)
                self.stopTheDrone()
                ccc = 0
                for __ in range(15):
                    rate2.sleep()
                    if self.stateMt.isArucoMarkerVisible:
                        break
                    ccc +=1
                if ccc > 8 :
                    print("Not possible to find Aruco" , self.droneName)
                    return False
        
        errorX,errorY,sideOfSquare=self.stateMt.pixelErrorX,self.stateMt.pixelErrorY,self.stateMt.sideOfSquare
    
        gX,gY,gZ=self.stateMt.gX,self.stateMt.gY,self.stateMt.positionZ
        tarX,tarY=0,0
        if (gY-1)%4 < 2.75 and (gY-1)%4 > 1.25:
            if gY < 1:
                tarY=1
            elif gY > 61:
                tarY=61
            else:
                if errorY > 0:
                    tarY=((gY-1)//4+1)*4 +1
                else:
                    tarY=((gY-1)//4)*4 +1
        else:
            if gY < 1:
                tarY=1
            elif gY > 61:
                tarY=61
            else:
                if abs(gY- (((gY-1)//4)*4 +1)) > abs(gY- (((gY-1)//4+1)*4 +1)):
                    tarY= ((gY-1)//4+1)*4 +1
                else:
                    tarY=  ((gY-1)//4)*4 +1
            tarX=gX+(gZ*errorX)/200

            print('target for this',self.droneName, 'is : ',tarX,tarY)
            #if gZ > 3.5:
            self.setPointGlobal((tarX,tarY,3))
            currZ=3
            #    currZ -=3
            #else:
            #    self.setPointGlobal((tarX,tarY,gZ))

        while  not rospy.is_shutdown():
            #calculating gains
            # error goes below 20 it will not change further
            if self.stateMt.isArucoMarkerVisible and self.stateMt.arucoColorId == 1:
                gY=self.stateMt.gY
                tarY=0
                if gY < 1:
                    tarY=1
                elif gY > 61:
                    tarY=61
                else:
                    if abs(gY- (((gY-1)//4)*4 +1)) > abs(gY- (((gY-1)//4+1)*4 +1)):
                        tarY= ((gY-1)//4+1)*4 +1
                    else:
                        tarY=  ((gY-1)//4)*4 +1
                print("!!!!!!!!!!!!!!!!!!!!!!!!!              Red  Aruco             !!!!!!!!!!!!!!!!!!!!!!!!       ")
                self.isRed=True
                self.redArucoSpots.append([self.stateMt.gX,tarY])
                self.handleBoycottBoxes(self.stateMt.gX,tarY)
                return False
            if not self.stateMt.isArucoMarkerVisible:
                ccc = 0
                self.goToPoint((self.stateMt.positionX,self.stateMt.positionY,currZ))
                for __ in range(15):
                    rate2.sleep()
                    if self.stateMt.isArucoMarkerVisible:
                        self.firstDetected=self.stateMt.positionX,self.stateMt.positionY,self.stateMt.positionZ
                        break
                    ccc+=1
                if ccc > 8:
                    print("trying to fix it" , self.droneName)
                    self.goToPoint(self.firstDetected)
                    self.stopTheDrone()
                    ccc = 0
                    for __ in range(15):
                        rate2.sleep()
                        if self.stateMt.isArucoMarkerVisible:
                            break
                        ccc +=1
                    if ccc > 8 :
                        print("Not possible to find Aruco" , self.droneName)
                        return False
                if self.stateMt.arucoColorId == 1:
                    gY=self.stateMt.gY
                    tarY=0
                    if gY < 1:
                        tarY=1
                    elif gY > 61:
                        tarY=61
                    else:
                        if abs(gY- (((gY-1)//4)*4 +1)) > abs(gY- (((gY-1)//4+1)*4 +1)):
                            tarY= ((gY-1)//4+1)*4 +1
                        else:
                            tarY=  ((gY-1)//4)*4 +1
                    self.redArucoSpots.append([self.stateMt.gX,tarY])
                    self.handleBoycottBoxes(self.stateMt.gX,tarY)
                    print("!!!!!!!!!!!!!!!!!!!!!!!!!              Red  Aruco             !!!!!!!!!!!!!!!!!!!!!!!!       ")
                    self.isRed=True
                    return False
            elif not self.stateMt.moreThanOneAruco :
                errorX,errorY,sideOfSquare = self.stateMt.pixelErrorX,self.stateMt.pixelErrorY,self.stateMt.sideOfSquare
                errorZ = currZ-self.stateMt.positionZ
                if abs(errorX) < 40 or stopX: #40
                    gainX=0
                    stopX = True
                else:
                    gainX=0.005
                if abs(errorY) < 40 or stopY: #40
                    gainY=0
                    stopY = True
                else:
                    gainY=0.005
                vel.linear.x , vel.linear.y , vel.linear.z = errorX*gainX,errorY*gainY,errorZ*0.2

                #velocity should not exceed than 1m/s
                if vel.linear.x > 1:
                    vel.linear.x = 1
                elif vel.linear.x < -1:
                    vel.linear.x = -1
                if vel.linear.y > 1:
                    vel.linear.y = 1
                elif vel.linear.y < -1:
                    vel.linear.y = -1

                self.local_vel_pub.publish(vel)      #publishing velocity setpoints
                #print( self.stateMt.gX,self.stateMt.gY)
                r2.sleep()
                #now if drone is above aruco is specific range it will procced to land

                if abs(errorY) < 50 and abs(errorX) < 50 and abs(self.stateMt.velX)<0.05 and abs(self.stateMt.velY)<0.05:
                    break
                if stopX and stopY :
                    break
            else:
                self.stopTheDrone()
                errorX,errorY,sideOfSquare=self.stateMt.pixelErrorX,self.stateMt.pixelErrorY,self.stateMt.sideOfSquare
            
                print('more than 1 aruco!!!')
                #self.stopTheDrone()
                if self.stateMt.moreThanOneAruco:
                    continue
                gX,gY,gZ=self.stateMt.gX,self.stateMt.gY,self.stateMt.positionZ
                tarX,tarY=0,0
                if gY < 1:
                    tarY=1
                elif gY > 61:
                    tarY=61
                else:
                    if errorY > -10:
                        tarY=((gY-1)//4+1)*4 +1
                    else:
                        tarY=((gY-1)//4)*4 +1
                tarX=gX+(gZ*errorX)/200
                print('target for this',self.droneName, 'is : ',tarX,tarY)
                #if gZ > 3.5:
                self.setPointGlobal((tarX,tarY,gZ-1))
                currZ=3
                #    currZ -=1
                #else:
                #    self.setPointGlobal((tarX,tarY,gZ))
                

            if  self.stateMt.arucoColorId == 1:
                gY=self.stateMt.gY
                tarY=0
                if gY < 1:
                    tarY=1
                elif gY > 61:
                    tarY=61
                else:
                    if abs(gY- (((gY-1)//4)*4 +1)) > abs(gY- (((gY-1)//4+1)*4 +1)):
                        tarY= ((gY-1)//4+1)*4 +1
                    else:
                        tarY=  ((gY-1)//4)*4 +1
                self.redArucoSpots.append([self.stateMt.gX,tarY])
                self.handleBoycottBoxes(self.stateMt.gX,tarY)
                print("!!!!!!!!!!!!!!!!!!!!!!!!!              Red  Aruco             !!!!!!!!!!!!!!!!!!!!!!!!       ")
                self.isRed=True
                return False
            
        
        print(self.droneName , "on spot done", self.stateMt.gX,self.stateMt.gY)
        if self.stateMt.arucoColorId == 1:
            gY=self.stateMt.gY
            tarY=0
            if gY < 1:
                tarY=1
            elif gY > 61:
                tarY=61
            else:
                if abs(gY- (((gY-1)//4)*4 +1)) > abs(gY- (((gY-1)//4+1)*4 +1)):
                    tarY= ((gY-1)//4+1)*4 +1
                else:
                    tarY=  ((gY-1)//4)*4 +1
            self.redArucoSpots.append([self.stateMt.gX,tarY])
            self.handleBoycottBoxes(self.stateMt.gX,tarY)
            print("!!!!!!!!!!!!!!!!!!!!!!!!!              Red  Aruco             !!!!!!!!!!!!!!!!!!!!!!!!       ")
            self.isRed=True
            return False
        return True

    def pickingBox(self):
        #-----------------------      go above aruco -------------------------------------------------------------------
        vel = Twist()
        #self.goToPoint((self.stateMt.positionX,self.stateMt.positionY,3))
        #going down to land
        stopX,stopY,stopZ = False,False,False
        rate = rospy.Rate(20.0)

        if self.stateMt.positionZ > 3.2:
            self.goToPoint((self.stateMt.positionX,self.stateMt.positionY,3))

        while  not rospy.is_shutdown() :
            if self.stateMt.positionZ > 3.2:
                self.goToPoint((self.stateMt.positionX,self.stateMt.positionY,3))

            if not self.stateMt.isArucoMarkerVisible:
                ccc = 0
                for _ in range(10):
                    rate.sleep()
                    if self.stateMt.isArucoMarkerVisible:
                        break
                    ccc += 1 
                if ccc > 8:
                    self.goToPoint((self.stateMt.positionX,self.stateMt.positionY-0.5,self.stateMt.positionZ+1))
                    stopZ=False
                    if not self.stateMt.isArucoMarkerVisible:
                        ccc = 0
                        for _ in range(10):
                            rate.sleep()
                            if self.stateMt.isArucoMarkerVisible:
                                break
                            ccc += 1 
                        if ccc > 8:
                            return False

            errorX,errorY,sideOfSquare=self.stateMt.pixelErrorX,self.stateMt.pixelErrorY,self.stateMt.sideOfSquare
            errorZ= 90-sideOfSquare #for defdefault SDF 
            
            if abs(errorX) < 20 :
                gainX=0
                stopX=True
            elif abs(errorX) < 50:
                gainX=0.003
            else:
                gainX=0.005
                stopX=False
            
            if abs(errorY) < 20 :
                gainY=0
                stopY=True
            elif abs(errorY) < 50:
                gainY=0.003
            else:
                gainY=0.005
                stopY=False
            
            if sideOfSquare > 50:
                gainZ= -0.005
            else :
                gainZ= -0.01
                stopZ=False
            if sideOfSquare > 70 or stopZ:
                gainZ = 0
                stopZ=True

            vel.linear.x , vel.linear.y , vel.linear.z = errorX*gainX , errorY*gainY , errorZ*gainZ
            
            #print(  self.pixelErrorX , self.pixelErrorY,"\t", vel.linear.x , vel.linear.y , vel.linear.z)
            self.local_vel_pub.publish(vel)
            rate.sleep()

            errorX,errorY,sideOfSquare=self.stateMt.pixelErrorX,self.stateMt.pixelErrorY,self.stateMt.sideOfSquare

            if (abs(errorY) < 30  and abs(errorX) < 30  and (sideOfSquare >= 70 or stopZ)) or (stopX and stopY and stopZ):
                self.ArucoId = self.stateMt.arucoColorId
                self.stopTheDrone()
                print("the way we want!!" , self.droneName)
                self.isLandingOnBox=True
                break
            
               
        print( "right now position is :", self.stateMt.gX,self.stateMt.gY,self.stateMt.positionZ )

        # !!!!!!!!!!!!!!!!                         pickUPBox                        !!!!!!!!!!!!!!!!!!!!!!!!!!!
        backUpX,backUpY = self.stateMt.positionX, self.stateMt.positionY
        # -----------------------------           landing in offboard mode       ------------------------------------

        print(self.droneName, "LANDING")
        corX,corY = self.stateMt.positionX, self.stateMt.positionY
        
        rate= rospy.Rate(20.0)
        r2  = rospy.Rate(2.5)
        velX,velY,velZ=0,0,-0.5
        eX,eY = 0,0
        while not rospy.is_shutdown() :
            eX,eY = corX-self.stateMt.positionX , corY-self.stateMt.positionY
            if eX > 0.025:
                velX=eX - 0.01
            else:
                velX=0
            if eY > 0.025:
                velY=eY - 0.01
            else:
                velY=0

            if self.stateMt.isGripperCheck and not self.stateMt.isArucoMarkerVisible:
                velZ = -0.2
                vel.linear.x , vel.linear.y , vel.linear.z = velX,velY,velZ
                self.local_vel_pub.publish(vel)
                rate.sleep()
                
                #if vertical velocity goes below this (as expected is -0.2) it will considered as touching the surface and now box is ready to drop
                if self.stateMt.velZ > -0.1:
                    r2.sleep()
                    if self.stateMt.velZ > -0.1:
                        # !!!!!!!!!!!!!!! means drone have touched the surface !!!!!!!!!!!!!!!!!
                        break   
                
            else:
                velZ = -0.5
                vel.linear.x , vel.linear.y , vel.linear.z = velX,velY,velZ
                self.local_vel_pub.publish(vel)
                rate.sleep()
            if self.stateMt.extended_state.landed_state == 1 or self.stateMt.extended_state.landed_state == 0  :
                print("to pickUp",self.droneName, self.stateMt.extended_state.landed_state , "landed as expected",self.stateMt.gX,self.stateMt.gY,self.stateMt.positionZ )
                break

            #if no vertical velocity is deteced the it must be landed in wrong place so it will try to land again
            if self.stateMt.velZ > -0.08:
                print("!!!!!!!!!!!!! NOt Landed as expected unable to catch box !!!!!!!!!!!!!!!!!!!!!!!" , self.droneName)
                r2.sleep()
                if self.stateMt.velZ > -0.08:
                    break
        print("to pickUp",self.droneName, self.stateMt.extended_state.landed_state , "landed as expected",self.stateMt.gX, self.stateMt.gY,self.stateMt.positionZ  )

        # ----------------------------------------------------------------------------------------
        result = self.ofb_ctl.activateGripper(True,droneName=self.droneName)
        rate.sleep()
        if result.result == False:
            ccc = 0
            for _ in range(10):
                rate.sleep()
                result = self.ofb_ctl.activateGripper(True,droneName=self.droneName)
                if result.result:
                    break
                ccc +=1
            if ccc > 8:
                print(self.droneName,"Error!! Didn't land properly")
                self.goToPoint((backUpX,backUpY,3))
                t = self.onSpot()
                if not t:
                    return False
                t = self.pickingBox()
                return t
        print("succes to catch gripper : ", self.droneName ,result, type(result.result))
        self.caughtAruco=True
        return True

    def checkIfBoycotted(self, gX=None,gY=None):

        if gX == None or gY==None:
            gX,gY,gZ=self.stateMt.gX,self.stateMt.gY,self.stateMt.positionZ
            if gY < 1:
                rowN=1
            elif gY > 61:
                rowN=15
            else:
                if abs(gY- (((gY-1)//4)*4 +1)) > abs(gY- (((gY-1)//4+1)*4 +1)):
                    rowN= (gY-1)//4
                else:
                    rowN=  (gY-1)//4+1
            rowN=int(rowN)
            spots=self.boycottSpots[rowN]
            #print(spots , rowN)
            for _ in spots:
                if gZ > 3:
                    if abs(_-self.stateMt.gX) < gZ + 0.5:
                        return True
                else:
                    if abs(_-self.stateMt.gX) < 3.5:
                        return True
                #print(abs(_-gX)) 
        else:
            if gY < 1:
                rowN=1
            elif gY > 61:
                rowN=15
            else:
                if abs(gY- (((gY-1)//4)*4 +1)) > abs(gY- (((gY-1)//4+1)*4 +1)):
                    rowN= (gY-1)//4
                else:
                    rowN=  (gY-1)//4+1
            rowN=int(rowN)
            spots=self.boycottSpots[rowN]
            gZ=self.stateMt.positionZ
            for _ in spots:
                if gZ > 3:
                    if abs(_-self.stateMt.gX) < gZ + 0.5:
                        return True
                else:
                    if abs(_-self.stateMt.gX) < 3.5:
                        return True
        return False

    def goOnPath(self,closest,reversePath,rowNumber,totalBoxes):
        pos=PoseStamped()
        rate = rospy.Rate(20.0)
        rate2=rospy.Rate(30.0)
        r2 = rospy.Rate(10)
        reverse = False
        targetPoints=[]
        
        rowNumber=int(rowNumber)

        self.redArucoSpots=[]
        self.caughtAruco=False
        #setpoints=  [[self.stateMt.gX,closest[1],3+self.baseHeight],[closest[0],closest[1],3+self.baseHeight],[60,closest[1],3+self.baseHeight]]
        if closest[0] < 40:
            setpoints=  [[self.stateMt.gX,closest[1],3+self.baseHeight],[closest[0],closest[1],3+self.baseHeight],[60,closest[1],3+self.baseHeight]]
        else:
            setpoints=  [[self.stateMt.gX,closest[1],3+self.baseHeight],[closest[0],closest[1],3+self.baseHeight],[-1,closest[1],3+self.baseHeight]]
        
        self.noDown=False
        if not reversePath:
            while len(setpoints)!=0:
                target=setpoints.pop()
                targetPoints.append(target)
        else:
            targetPoints=setpoints[:]

        boycottedSpots = self.boycottSpots[rowNumber]

        while len(targetPoints)!=0:
            
            lastPoint = targetPoints[-1]
            target = targetPoints[-1]
            tarX=target[0]-self.homepose[0] 
            tarY=target[1]-self.homepose[1]
            tarZ=target[2]
            detected=False
            reverse=False
            pos.pose.position.x, pos.pose.position.y, pos.pose.position.z  = tarX,tarY,tarZ
            currX,currY,currZ=self.stateMt.positionX,self.stateMt.positionY,self.stateMt.positionZ
            if abs(tarY-currY) > 30:
                self.ofb_ctl.set_parameter('MPC_XY_VEL_MAX',set_param_value_real=10.0,droneName=self.droneName) 
            else:
                self.ofb_ctl.set_parameter('MPC_XY_VEL_MAX',set_param_value_real=5.0,droneName=self.droneName)
            self.local_pos_pub.publish(pos)
            rate.sleep()
            self.isRed=False
            print()

            bo = True
            #print("Going to : ",target)
            while  not rospy.is_shutdown():
            #if ArucoDetected then this landOnAruco function will be called and we will firstly land on the box
                if not self.stateMt.state.armed or not self.stateMt.state.mode=="OFFBOARD":
                    self.armingDrone()

                if self.stateMt.isArucoMarkerVisible:
                    t = self.checkIfBoycotted()
                    if t:
                        self.stateMt.isArucoMarkerVisible=False
                        r2.sleep()
                        continue
                    self.firstDetected = (self.stateMt.positionX,self.stateMt.positionY,self.stateMt.positionZ)
                    self.stopTheDrone()
                    detected=True
                    t = self.checkIfBoycotted()
                    if not t:
                        #print("Time for onSpot" , boycottedSpots)
                        t = self.onSpot()
                        if not t :
                            reverse=True
                            break
                        t = self.pickingBox()
                        if not t :
                            reverse=True
                            break
                    else:
                        self.stateMt.isArucoMarkerVisible=False
                    break
                
                currX,currY,currZ=self.stateMt.positionX,self.stateMt.positionY,self.stateMt.positionZ
                if (abs(tarX-currX) < 0.2 and abs(tarY-currY) < 0.2 and abs(tarZ-currZ)<0.2):
                    print("Reachead !!! at ",self.stateMt.gX,self.stateMt.gY,self.stateMt.positionZ)
                    break
                if len(self.boycottSpots[rowNumber]) - len(boycottedSpots) >= totalBoxes:
                    break
                rate2.sleep()
            #self.stateMt.isArucoMarkerVisible=False
            if reverse:
                if len(self.redArucoSpots) >= totalBoxes:
                    print()
                    print('all boxes are over!!')
                    break
                print("Going reverse !!!!!!" , len(self.boycottSpots[rowNumber]),len(boycottedSpots), totalBoxes)
                #targetPoints.append(lastPoint)
                #targetPoints.pop()
                continue
            if detected:
                break
            if len(self.boycottSpots[rowNumber]) - len(boycottedSpots) >= totalBoxes:
                print()
                print('all boxes are over!!')
                break
            print("targetPoints : ",targetPoints , "\t", "closest : ", closest)
            #if targetPoints[-1][0]==closest[0] and targetPoints[-1][1]==closest[1]:
            #    print()
            #    print("!!!!!!             NO DOWN          !!!!!!!!!!!!!!!!")
            #    break
            #    #self.noDown=True
            targetPoints.pop()
        #arming again and moving above
        self.armingDrone()
        self.goToPoint((self.stateMt.positionX, self.stateMt.positionY, 3.5+self.baseHeight))
        
    def droppingBox(self,droppingLocation):
        if droppingLocation[1] < 1:
            self.setPointGlobal((droppingLocation[0],1,3.5+self.baseHeight),absoluteErrorMargin=(1,1.5,2))
        else:
            self.setPointGlobal((droppingLocation[0]+1,61,3.5+self.baseHeight),absoluteErrorMargin=(1,1.5,2))

        self.setPointGlobal((droppingLocation[0],droppingLocation[1],3.5+self.baseHeight),absoluteErrorMargin=(1,1.5,2))
        print()
        print(self.droneName, "LANDING")
        tarX=droppingLocation[0]-self.homepose[0] 
        tarY=droppingLocation[1]-self.homepose[1]
        disZ=self.stateMt.positionZ
        rate= rospy.Rate(15.0)
        r2  = rospy.Rate(2.5)
        vel = Twist()
        
        if droppingLocation[1] < 1:
            #-------------------------------------- staying on spot       -------------------------------
            self.setPointGlobal((droppingLocation[0],droppingLocation[1],2.5),absoluteErrorMargin=(1,1.5,2))
            #-------------------------------------------     landing on floor to drop -------------------------------------------------------------------------
            self.setPointGlobal((droppingLocation[0],droppingLocation[1],2.2),absoluteErrorMargin=(1,1.5,2))
        else:
             self.setPointGlobal((droppingLocation[0],droppingLocation[1],2),absoluteErrorMargin=(1.5,1.5,0.5))
           
        #------------------       dropping the box                 ---------------------------------------------
        result = self.ofb_ctl.activateGripper(False,droneName=self.droneName)
        rate.sleep()
        print("dropping the box : ", self.droneName ,result, type(result.result))
        print('dropping error',droppingLocation[0]-self.stateMt.gX,droppingLocation[1]- self.stateMt.gY)
        self.armingDrone()
        self.goToPoint((self.stateMt.positionX,self.stateMt.positionY,3+self.baseHeight))
        if self.stateMt.gY < 1:
            self.setPointGlobal((self.stateMt.gX,1,3+self.baseHeight))
        else:
            self.setPointGlobal((self.stateMt.gX,61,3+self.baseHeight))


#this will control multiple drones parallely
class control_multiple_drone:
    def __init__(self,truck_cells, truck_heights,ofb_ctl=None):
        self.boxRows=[]
        self.truck_cells = truck_cells
        self.truck_heights = truck_heights

        self.ofb_ctl=ofb_ctl
        self.rowsTaken = {}
        self.drones_object = []
        self.Threads = []                     #will store threads of drones

        self.redArucoSpots=[]
        self.noDownRows=np.zeros(15,dtype=bool)
        self.reachedStartingPoint=np.zeros(15,dtype=bool)

        
        self.closestPoints=np.ones(16)*-1
        
        rospy.Subscriber("/spawn_info",UInt8, self.setRowsCallback) 
        
    def setRowsCallback(self,data):
        self.boxRows.append(data.data)
        self.boxRows.sort()
    def closest(self, coXY,droneName, anotherDroneName):       #this will give closest point where drone can go

        def totalCopy(l,i):
            ans=0
            for _ in l:
                if _ == i:
                    ans+=1
            return ans
        m = 1000
        ans = [0,0]
        count = 0
        before = m
        if anotherDroneName=='':
            exce=-1
        else:
            exce = self.rowsTaken[anotherDroneName]
        latestX=0
        selectedRow= 0
        for _ in self.boxRows:
            if _ == exce and exce != -1:
                continue
            before = m
            if self.reachedStartingPoint[_]:
                latestX=self.closestPoints[_]
            else:
                latestX=-1
            m = min( ((coXY[0]-latestX)**2 +(coXY[1]-1-(_-1)*4)**2)**0.5 ,m )
            if m != before:
                ans=[latestX,1+(_-1)*4]              #initial point of row e.g.  (-1,17),(-1,15)
                selectedRow = _ 
            before = m
            m = min( ((coXY[0]-60)**2+(coXY[1]-1-(_-1)*4)**2)**0.5 ,m )
            if m != before:
                ans=[60,1+(_-1)*4]              #initial point of row e.g.  (60,17),(60,15)
                selectedRow = _ 
            count += 1
        if m == 1000 and selectedRow==0:
            exce = -1
            for _ in self.boxRows:
                if _ == exce and exce != -1:
                    continue
                before = m
                if self.reachedStartingPoint[_]:
                    latestX=self.closestPoints[_]
                else:
                    latestX=-1
                m = min( ((coXY[0]-latestX)**2 +(coXY[1]-1-(_-1)*4)**2)**0.5 ,m )
                if m != before:
                    ans=[latestX,1+(_-1)*4]              #initial point of row e.g.  (-1,17),(-1,15)
                    selectedRow = _ 
                before = m
                m = min( ((coXY[0]-60)**2+(coXY[1]-1-(_-1)*4)**2)**0.5 ,m )
                if m != before:
                    ans=[60,1+(_-1)*4]              #initial point of row e.g.  (60,17),(60,15)
                    selectedRow = _ 
                count += 1
        self.rowsTaken[droneName] = selectedRow
        return ans,selectedRow, totalCopy(self.boxRows,selectedRow)
    def deleteElement(self, coY):
        element = int(coY//4) + 1
        print(self.boxRows)
        if coY%4 > 1.5:
            print("Check if drone Landed properly!!! at " , element )
        print("Deleted Box at row : ___________- " , element)
        del self.boxRows[self.boxRows.index(element)]
        print(self.boxRows)
        pass
    
    def handleReachedStartingPoint(self,gX,gY):
        if gX < 7:
            if gY < 1:
                rowN=1
            elif gY > 61:
                rowN=15
            else:
                if abs(gY- (((gY-1)//4)*4 +1)) > abs(gY- (((gY-1)//4+1)*4 +1)):
                    rowN= (gY-1)//4
                else:
                    rowN=  (gY-1)//4+1
            rowN=int(rowN)
            self.reachedStartingPoint[rowN] = True
            print("Reached at Starting point of row " , rowN)
    
    def handleClosestPoint(self,gX,gY):
        if gY < 1:
            rowN=1
        elif gY > 61:
            rowN=15
        else:
            if abs(gY- (((gY-1)//4)*4 +1)) > abs(gY- (((gY-1)//4+1)*4 +1)):
                rowN= (gY-1)//4
            else:
                rowN=  (gY-1)//4+1
        rowN=int(rowN)

        posX = self.closestPoints[rowN]
        if gX+4>posX:
            self.closestPoints[rowN]=gX+4
        print()
        print("CLoses point of row : ", rowN, "is " , self.closestPoints[rowN])

    def handleRedAruco(self, redArucoList):
        anyMatch=False
        print()
        print("Checking list : ", redArucoList)
        print("List before :", self.redArucoSpots)
        for _ in redArucoList:
            anyMatch=False
            for __ in self.redArucoSpots:
                if abs(__[0]-_[0]) < 3 and __[1]==_[1]:
                    anyMatch=True
                    break
            if not anyMatch:
                self.redArucoSpots.append(_)
                self.handleReachedStartingPoint(_[0],_[1])
                self.handleClosestPoint(_[0],_[1])
                self.deleteElement(_[1])
        print("After handle Red Aruco: ",self.redArucoSpots)
    #this will give co-ordinates of truck where box is supoosed to drop
    def dropLocation(self, color, droneName):           
        xy = self.truck_cells[color].pop()
        height= 1.7                   #self.truck_heights[droneName][color]
        return xy,height
    
    #this will create drone objects
    #within this it will check whethers all subscribers are ready so that drone could go in offboard mode
    def createDroneObjects(self,drones=['edrone1','edrone0'], hompose=[(-1,61),(-1,1)]):
        self.drones_object.clear()
        droneName=''
        homepose= [0,0]
        edrone=None
        for _ in range(len(drones)):
            droneName=drones[_]
            homepose=hompose[_]
            self.drones_object.append( single_drone_control(stateMoniter(droneName,homepose),droneName,homepose,height= _ ,ofb_ctl=self.ofb_ctl) )
            self.rowsTaken[droneName] = -1 
        for _ in range(len(drones)):
            edrone=self.drones_object[_]
            for __ in range(len(drones)):
                if _ != __:
                    edrone.anotherDrones.append(self.drones_object[__])

    #this is the main function
    def mainFun(self, edrone):
        rate=rospy.Rate(20.0)
        #edrone.ofb_ctl.set_parameter('MPC_XY_VEL_MAX',set_param_value_real=10.0,droneName=self.droneName)
        
        edrone.armingDrone()
        edrone.setPointGlobal((edrone.stateMt.gX,edrone.stateMt.gY,3+edrone.baseHeight))   #takeofff !!!!
        rowNumber=0
        while len(self.boxRows) != 0 : 
            #going to closest starting point of row e.g (-1,17) or (60,17) as row starts and ends at these points
            if len( edrone.anotherDrones) != 0 :
                closest,rowNumber, totalBoxes = self.closest([edrone.stateMt.gX,edrone.stateMt.gY], edrone.droneName, edrone.anotherDrones[0].droneName)
            else :
                closest,rowNumber, totalBoxes = self.closest([edrone.stateMt.gX,edrone.stateMt.gY], edrone.droneName, '')

            print()
            print(closest,rowNumber, totalBoxes)
            edrone.goOnPath(closest,self.noDownRows[rowNumber],rowNumber,totalBoxes)
            
            self.handleRedAruco(edrone.redArucoSpots)
            if edrone.noDown == True:
                print()
                print("NO Down :",rowNumber)
                print()
                self.noDownRows[rowNumber] = True
            if edrone.ArucoId == 1:
                color='red'
            else:
                color='blue'
            if edrone.caughtAruco:
                self.handleReachedStartingPoint(edrone.stateMt.gX,edrone.stateMt.gY)
                self.handleClosestPoint(edrone.stateMt.gX,edrone.stateMt.gY)
                print(edrone.droneName , " ready to drop the box at location")
                xy,height= self.dropLocation(color,edrone.droneName)
                print(xy)
                self.deleteElement(edrone.stateMt.gY)
                edrone.droppingBox(xy)

            if len(self.boxRows) == 0:         #if their are no rows left then drones will go back to initial position and land
                edrone.setPointGlobal((edrone.stateMt.gX,edrone.stateMt.gY,4+edrone.baseHeight))
                edrone.setPointGlobal((edrone.homepose[0],edrone.homepose[1],4+edrone.baseHeight))
                edrone.ofb_ctl.setAutoLandMode(droneName=self.droneName)
                while not rospy.is_shutdown():
                    if edrone.stateMt.extended_state.landed_state == 1 or edrone.stateMt.extended_state.landed_state == 0 :
                        rate.sleep()
                        break
                edrone.ofb_ctl.setArm(False,droneName=self.droneName)
            print('--------------------------------------------------------------------------------------------')
            print()
    #this will create threads and also start them
    def createThreads(self):
        for _ in self.drones_object:
            t = threading.Thread(target=self.mainFun,args=(_,))
            self.Threads.append(t)
            t.start()

    def executeThreads(self): #currently this is not in use but it can if we want to activate it in this way
        for _ in self.Threads:
            _.start()



def main():
    droneNames=['edrone0','edrone1'] 
    x1=14.2
    x2=15.8
    blue_cells=[]
    for _ in range(2):
        y=-7.6
        for __ in range(5):
            blue_cells.append([x1,y])
            blue_cells.append([x2,y])
            y += 0.675
        x1+=0.8
        x2+=0.8

    x1=56.5 + 3*0.85
    x2=56.5 + 0.85
    y=64.75
    red_cells=[]
    for _ in range(3):
        y=64.75
        for __ in range(3):
            red_cells.append([x1,y+(__*1.23)])
            red_cells.append([x2,y+(__*1.23)])

    truck_cells = {'blue':blue_cells,'red':red_cells}
    truck_heights= {'blue':1.7 , 'red':1.7}

    ofb_ctl=offboard_control()
    control_d = control_multiple_drone(  truck_cells, truck_heights,ofb_ctl=ofb_ctl)   #drones=['edrone0'], hompose=[(-1,1)]
    control_d.createDroneObjects(drones=['edrone1','edrone0'], hompose=[(-1,61),(-1,1)]) #drones=['edrone1','edrone0'], hompose=[(-1,61),(-1,1)]
    control_d.createThreads()
    #print(control_d.Threads, len(control_d.Threads)  )
    #print(control_d.rows, len(control_d.rows)  )
    #control_d.executeThreads()
    

    
if __name__ == '__main__':
    try:
        main()
    except rospy.ROSInterruptException:
        print("Errror!!")
        pass



 