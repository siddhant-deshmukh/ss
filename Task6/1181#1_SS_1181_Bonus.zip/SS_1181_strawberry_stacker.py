#!/usr/bin/env python3

from itertools import count
from lib2to3.pgen2.token import RPAR
from re import S
from tabnanny import check
from turtle import color, speed

from soupsieve import closest
import rospy
from std_msgs.msg import UInt8
from geometry_msgs.msg import *
from mavros_msgs.msg import *
from mavros_msgs.srv import *
from gazebo_ros_link_attacher.srv import *
from rospy.impl.transport import BIDIRECTIONAL
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError
import cv2
import numpy as np
import threading


'''
* Team Id : <1181>
* Author List : Siddhant Deshmukh, Girish Kolhe, Aditya Agrawal, Pranav Chole
* Filename: <SS_1181_strawberry_stacker.py>
* Theme: <StrawBerry Stacker>

* Class : <offboard_control, stateMoniter, single_drone_control, control_multiple_drone>
* Functions: <main()>

* Global Variables: <None>
'''



'''
#this will hold methods needed to operate drone in offboard
#like arming, changing drone mode, activate gripper, setting parameters

#used while creating single_drone_control object
'''
class offboard_control:
    def __init__(self):
        # Initialise rosnode
        rospy.init_node('strawberry_stacker', anonymous=True) 
    def setArm(self, value=True,droneName='edrone1'):
        # Calling to /mavros/cmd/arming to arm the drone and print fail message on failure
        rospy.wait_for_service(droneName+'/mavros/cmd/arming')  # Waiting untill the service starts 
        try:
            armService = rospy.ServiceProxy(droneName+'/mavros/cmd/arming', mavros_msgs.srv.CommandBool) # Creating a proxy service for the rosservice named /mavros/cmd/arming for arming the drone 
            result=armService(value)
            print(result)
        except rospy.ServiceException as e:
            print ("Service arming call failed: %s"%e)
    # Similarly delacre other service proxies 
    
    #this will set the mode of drone to offboard mode
    def offboard_set_mode(self,droneName='edrone1'):
        # Call /mavros/set_mode to set the mode the drone to OFFBOARD
        # and print fail message on failure
        rospy.wait_for_service(droneName+'/mavros/set_mode')
        try:
            setMode=rospy.ServiceProxy(droneName+'/mavros/set_mode',mavros_msgs.srv.SetMode)
            result=setMode(custom_mode='OFFBOARD')
            #print("set mode to offboard")
            print(result)
        except rospy.ServiceException as e:
            print ("Service offvoard set_mode call failed: %s"%e)        
    #this will set the mode of drone to autoLandMOde
    def setAutoLandMode(self,droneName='edrone1'):
        rospy.wait_for_service(droneName+'/mavros/set_mode')
        try:
            flightModeService = rospy.ServiceProxy(droneName+'/mavros/set_mode', mavros_msgs.srv.SetMode)
            flightModeService(custom_mode='AUTO.LAND')
        except rospy.ServiceException as e:
            print("service set_mode call failed: %s. Autoland Mode could not be set."%e)
    #this will change the specific parameter 
    def set_parameter(self,paramId='COM_RCL_EXCEPT',set_param_value_integer=2,set_param_value_real=2.0,droneName='edrone1'):
        rospy.wait_for_service(droneName+'/mavros/param/set')
        try:

            setParams=rospy.ServiceProxy(droneName+'/mavros/param/set',mavros_msgs.srv.ParamSet)
            paramValue= ParamValue()
            paramValue.real=set_param_value_real
            response=setParams(param_id=paramId,value=paramValue)
            return response.success
            #print("Done here!!")
            #print("setting parameter", paramId , response.success , response.value.real)
        except rospy.ServiceException as e:
            print("Service  set_Parameters call failed: %s"%e)
    #this will activate the gripper to catch the box
    def activateGripper(self, setValue=True,droneName='edrone1'):
        print("trying to activate Gripper")
        rospy.wait_for_service(droneName+"/activate_gripper")
        try:
            gripper = rospy.ServiceProxy(droneName+'/activate_gripper', Gripper )
            result = gripper(activate_gripper=setValue)
            #print("result of activaGripper : " , result)
            return result
        except rospy.ServiceException as e:
            print("service activaGripper call failed: %s. Autoland Mode could not be set."%e)

'''
# this will hold current state of drone
 like 
 1. position
 2.  velocity
 3. is gripper ready
 4. is aruco visible

 and it does most of the operation on image take from camera
'''
class stateMoniter:

    def __init__(self , droneName, homepose):
        self.state = State()
        # Instantiate a setpoints message
        self.positionX=0            #x position of drone in drone frame
        self.positionY=0            #y position of drone in drone frame 
        self.positionZ=0            #z height of drone 

        self.gX = 0              #co-ordinates of drone in global frame
        self.gY = 0

        self.droneName = droneName              #name of drone
        self.homepose = homepose                #home position of drone in global frame

        self.velX=0
        self.velY=0
        self.velZ=0                        #velocity of drone

        self.isGripperCheck=False           # wil check if gripper is ready to catch
        self.img = np.empty([])             # This will contain your image frame from camera
        self.bridge = CvBridge() 

        self.isArucoMarkerVisible=False         #this shows wither Aruco Marker is their or not
        
        #this will save the errors
        self.pixelErrorX=0               #x distance between the center of caemra and center of AruCo
        self.pixelErrorY=0               #y distance between the center of caemra and center of AruCo
        self.sideOfSquare =1                  #x distance between two corners of AruCo 1st and 4th

        self.moreThanOneAruco = False
        self.extended_state = ExtendedState()

        topic_name=['ext_state', 'local_pos','state','mission_wp']       #this topics are used to check whether it is ready to take off or not
        self.sub_topics_ready = {}
        for _ in topic_name:
            self.sub_topics_ready[_] = False

        self.setToLandOnAruco = False
        self.arucoColorId = 0

    def stateCb(self, msg):
        # Callback function for topic /mavros/state
        self.state = msg

        if not self.sub_topics_ready['state'] : #and msg.connected
            self.sub_topics_ready['state'] = True
    def setPositionCallback(self ,data):
        #to keep track of drone position
        self.positionX=data.pose.position.x 
        self.positionY=data.pose.position.y 
        self.positionZ=data.pose.position.z

        self.gX=data.pose.position.x + self.homepose[0]
        self.gY=data.pose.position.y + self.homepose[1]

        if not self.sub_topics_ready['local_pos']:
            self.sub_topics_ready['local_pos'] = True
    def setVelocityCallback(self,data):
        #to keep tarck of drone velocity
        self.velX=data.twist.linear.x 
        self.velY=data.twist.linear.y 
        self.velZ=data.twist.linear.z
    def gripperCheck(self, data):
        #to check if gripper is ready to activate or not
        if data.data == 'True':
            self.isGripperCheck=True
        else:
            self.isGripperCheck=False
    def extended_state_callback(self, data):
        self.extended_state = data                   #to check whether drone have landed or not (in autoLandMode)

        if not self.sub_topics_ready['ext_state']:
            self.sub_topics_ready['ext_state'] = True
    def mission_wp_callback(self,data):                   #this is only to check if drone is ready to go in offboard mode
        if not self.sub_topics_ready['mission_wp']:
            self.sub_topics_ready['mission_wp'] = True
    

    '''
    * Function Name: <ImageCallback>
    * Input:        Will take an image as input from image publisher
    * Output:       assign 
                    1. Color of Aruco (self.arucoColorId)
                    2. Are their more than one aruco (self.moreThanOneAruco)
                    3. Is aruco marker visible (isArucoMarkerVisible)
                    4. And how far center of aruco is from camera (self.positionX,self.positionY)
                    5. How many pixel are in the side of Aruco (side of square)
    '''
    def imageCallBack(self,img):
        try:
            img = self.bridge.imgmsg_to_cv2(img, "bgr8")               # Converting the image to OpenCV standard image
            
            self.isArucoMarkerVisible=False         #this shows wither Aruco Marker is their or not
            
            #this will save the errors
            self.pixelErrorX=0               #x distance between the center of caemra and center of AruCo
            self.pixelErrorY=0               #y distance between the center of caemra and center of AruCo
            self.sideOfSquare =1                  #x distance between two corners of AruCo 1st and 4th
            
            #detecting aruco and its corners
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            aruco_dict = cv2.aruco.Dictionary_get(cv2.aruco.DICT_5X5_250)
            parameters = cv2.aruco.DetectorParameters_create()
            corners, ids, _ = cv2.aruco.detectMarkers(gray, aruco_dict, parameters = parameters)
            
            self.arucoColorId = -1
            if len(corners)==0 :    #means no aruco is visible
                self.isArucoMarkerVisible=False
            else:  
                if len(corners) != 0: 
                    self.isArucoMarkerVisible=True

            height, width, _ = img.shape          #height and widthe of image
            if  len(corners)!=0 :
                #if only one aruco is visible
                if len(ids) == 1:
                    self.moreThanOneAruco=False

                    markerCorner=corners[0]
                    #center of Aruco
                    cXY=(int((markerCorner[0][0][0] + markerCorner[0][2][0])//2),int((markerCorner[0][0][1] + markerCorner[0][2][1])//2))
                    
                    #how many pixels are their in side of Aruco 
                    #this will tell us how close drone is frome Aruco in height
                    self.sideOfSquare=abs(int(((markerCorner[0][3][0] - markerCorner[0][0][0])**2+(markerCorner[0][3][1] - markerCorner[0][0][1])**2)**0.5))
                    
                    #how many pixels are in between center of Aruco and center of image
                    self.pixelErrorX=(cXY[0]-width//2)
                    if self.positionZ < 3.2 :
                        #because camera is not at center position of drone self.pixelError is modified
                        self.pixelErrorY=(height//2)-(cXY[1]- (1.25*self.sideOfSquare) - 13.5) #for default SDF file
                    else:
                        self.pixelErrorY=height//2 - cXY[1]
                    
                    # assinging Id of Aruco
                    self.arucoColorId=ids[0][0]
                
                else: #more than one Aruco are visible
                    self.moreThanOneAruco=True      #declaring that their are moer than one aruco

                    minDis = 400
                    currDis = 400
                    cXY = (200,200)
                    currXY = (200,200)
                    ss=10
                    index=0
                    count=0
                    # selecting the closest aruco from center of image
                    for markerCorner in corners:
                        #center of Aruco
                        currXY=(int((markerCorner[0][0][0] + markerCorner[0][2][0])//2),int((markerCorner[0][0][1] + markerCorner[0][2][1])//2))
                        #pixel between center of image and aruco center 
                        currDis = ((currXY[0]-200)**2 + (currXY[1]-200)**2)**0.5
                        if currDis < minDis:
                            minDis = currDis
                            cXY=currXY
                            index =count
                        count+=1
                    
                    #how many pixels are their in side of Aruco 
                    #this will tell us how close drone is frome Aruco in height
                    markerCorner = corners[index]
                    self.arucoColorId=ids[index][0]    # assinging Id of Aruco
                    self.sideOfSquare=abs(int(((markerCorner[0][3][0] - markerCorner[0][0][0])**2+(markerCorner[0][3][1] - markerCorner[0][0][1])**2)**0.5))
                    
                    #how many pixels are in between center of Aruco and center of image
                    self.pixelErrorX=(cXY[0]-width//2)
                    if self.positionZ < 3 :
                        #because camera is not at center position of drone self.pixelError is modified
                        self.pixelErrorY=(height//2)-(cXY[1]- (1.25*self.sideOfSquare) - 13.5) #for default SDF file
                    else:
                        self.pixelErrorY=height//2  - cXY[1]


        except CvBridgeError as e:
            print(e)
            return


'''
this class basically controls the function of single drone like 
    1. Arming the drone
    2. moving it 
    3. picking box
    4. going to some point
'''
#this class will contain all methods to control drone
class single_drone_control:
    def __init__(self, stateMt, droneName='edrone1',homepose=(-1,1) , height=0,ofb_ctl=None):
        #this function can be used to arm the drone or setting mode to OFFBOARD mode

        self.droneName=droneName                #name of the drone
        self.cameraName=droneName               #name of camera
        self.ofb_ctl=ofb_ctl                    # offboard_control object (see first class offboard_control)
        self.stateMt=stateMt                    # stateMoniter object (see 2nd class stateMoniter)
        self.homepose=homepose                 #homposition of drone

        self.baseHeight  = height             #baseheight different for different drone so that they woould not collide with each otehr
        self.isLandingOnBox = False
        self.firstDetected = None             #location where the aruco was visible last time

        self.anotherDrones = []               #another drone's object
        self.ArucoId = 0                      #current arucoId drone is above

        self.caughtAruco=False                #does aruco get catch
        # from where the drone is coming
        #this helps us to guess where to go like if drone is from blue then it will go towards (x=60) otherwise (x=0)
        self.isFrom = ''                      
        
        #publishers
        self.local_pos_pub = rospy.Publisher(self.droneName+'/mavros/setpoint_position/local', PoseStamped, queue_size=10)
        self.local_vel_pub = rospy.Publisher(self.droneName+'/mavros/setpoint_velocity/cmd_vel_unstamped',Twist, queue_size=10)
        #subscribers
        rospy.Subscriber(self.droneName+"/mavros/state",State, self.stateMt.stateCb)
        rospy.Subscriber(self.droneName+"/mavros/local_position/pose", PoseStamped, self.stateMt.setPositionCallback)
        rospy.Subscriber(self.droneName+"/gripper_check",std_msgs.msg.String , self.stateMt.gripperCheck )
        
        rospy.Subscriber(self.cameraName+"/camera/image_raw",Image,self.stateMt.imageCallBack)
        rospy.Subscriber(self.droneName+"/mavros/local_position/velocity_local",TwistStamped,self.stateMt.setVelocityCallback)
        rospy.Subscriber(self.droneName+'/mavros/extended_state',ExtendedState, self.stateMt.extended_state_callback)
        
        rospy.Subscriber(self.droneName+'/mavros/mission/waypoints', WaypointList, self.stateMt.mission_wp_callback)

        #will wait for topics to be ready
        if self.wait_for_topics(60):
            print("Ready to fly!!" , self.droneName)
        else:
            print("Failed to fly!!!" ,self.droneName)
        
        #setting parameters
        self.ofb_ctl.set_parameter('COM_DISARM_LAND',set_param_value_real= 5.0,droneName=self.droneName)
        self.ofb_ctl.set_parameter('MPC_XY_VEL_MAX',set_param_value_real=5.0,droneName=self.droneName)  #to control maximum automatic speed of Drone                                                                  #will be good if kept less than 5
        self.ofb_ctl.set_parameter('MPC_LAND_ALT1',set_param_value_real=3.0,droneName=self.droneName)
        self.ofb_ctl.set_parameter('MPC_LAND_ALT2',set_param_value_real=1.2,droneName=self.droneName)
    
    #to arm drone if it is not arm or to go in offboard mode if it is not in offboard mode

    '''
    Is getting called in :          __init__

    Function : It waits till only required publishers start publishing and we can wait as the subscriber
    otherwise drone didn't go in offboard mode properly
    '''
    def wait_for_topics(self, timeout):
        
        rospy.loginfo("waiting for subscribed topics to be ready")
        loop_freq = 5  # Hz
        rate = rospy.Rate(loop_freq)
        simulation_ready = False
        for i in range(timeout * loop_freq):
            if all(value for value in self.stateMt.sub_topics_ready.values()):
                simulation_ready = True
                break
            try:
                rate.sleep()
            except rospy.ROSException as e:
                self.fail(e)
        return simulation_ready

    '''
    #this will arm drone if it is not armed and set mode to offboard if it is not in offboard mode
    '''
    def armingDrone(self):
        pos =PoseStamped()
        pos.pose.position.x = 0
        pos.pose.position.y = 0
        pos.pose.position.z = 0

        rate = rospy.Rate(20.0)
        if self.stateMt.state.mode != "OFFBOARD":
            for i in range(100):
                self.local_pos_pub.publish(pos)
                rate.sleep()
        while not self.stateMt.state.armed:               #checking if it is already armed or not
            self.ofb_ctl.setArm(droneName=self.droneName)
            rate.sleep()
            print("Arming!!")
        while not self.stateMt.state.mode=="OFFBOARD":
            self.ofb_ctl.offboard_set_mode(droneName=self.droneName)
            rate.sleep()
            print ("OFFBOARD mode being activated")
    
    '''
    this will add single_drone_control objects of other drones available in field to variable self. anotherDrone
    '''
    def setAnotherDrone(self, object):
        self.anotherDrones=object
    
    '''
    #to stop the Drone it will reduce drone x y speed to 0
    '''
    def stopTheDrone(self):
        vel=Twist()
        vel.linear.x = 0
        vel.linear.y = 0
        vel.linear.z = 0
        rate = rospy.Rate(20.0)
        self.local_vel_pub.publish(vel)
        while not rospy.is_shutdown():
            rate.sleep()
            if abs(self.stateMt.velX)<0.05 and abs(self.stateMt.velY)<0.05:
                break
        return
    
    '''
    #works for local-coordinates only 

    Function Name: <goToPoint>
    * Input: target, absoluteMargin
    * Output: moves drone to the target from current location
    * Logic: 
        target is recived and then it is published 
        now we will wait till it reaches to the target point
    '''
    def goToPoint(self, target, absoluteErrorMargin=(0.2,0.2,0.2) ):
        
        tarX,tarY,tarZ=target
        pos=PoseStamped()
        rate = rospy.Rate(20.0)
        rate2=rospy.Rate(50.0)
        pos.pose.position.x, pos.pose.position.y, pos.pose.position.z  = tarX,tarY,tarZ
        currX,currY,currZ=self.stateMt.positionX,self.stateMt.positionY,self.stateMt.positionZ
        
        self.local_pos_pub.publish(pos)
        #rate.sleep()
        abs1,abs2,abs3=absoluteErrorMargin
        #waiting till drone goes in allowable range
        while  not rospy.is_shutdown():
            #if ArucoDetected then this landOnAruco function will be called and we will firstly land on the box
            if not self.stateMt.state.armed or not self.stateMt.state.mode=="OFFBOARD":
                self.armingDrone()
            currX,currY,currZ=self.stateMt.positionX,self.stateMt.positionY,self.stateMt.positionZ

            #if the target is in range then break the loop
            if (abs(tarX-currX) < abs1 and abs(tarY-currY) < abs2 and abs(tarZ-currZ)<abs3):
                break
            rate2.sleep()
        rate.sleep() 
    
    '''
    #works for global-coordinates only 

    Function Name: <setPointGlobal>
    * Input: target, absoluteMargin, speed
    * Output: moves drone to the target from current location with spcified speed
    * Logic: 
        target is recived and then it is published using goToPoint function
        first it convert the target points into local points as per drone using homepose
        now we will wait till it reaches to the target point
    '''
    def setPointGlobal(self,target, absoluteErrorMargin=(0.2,0.2,0.2) ,speed=None):
        if speed!= None:
            self.ofb_ctl.set_parameter('MPC_XY_VEL_MAX',set_param_value_real=speed,droneName=self.droneName)
        else:
            if abs(target[0]-self.stateMt.gX) > 30 or abs(target[1]-self.stateMt.gY) > 30 :
                self.ofb_ctl.set_parameter('MPC_XY_VEL_MAX',set_param_value_real=10.0,droneName=self.droneName)
            else:
                self.ofb_ctl.set_parameter('MPC_XY_VEL_MAX',set_param_value_real=5.0,droneName=self.droneName)
            
        tarX=target[0]-self.homepose[0] 
        tarY=target[1]-self.homepose[1]
        tarZ=target[2]
        print(self.droneName," target is : ",  target, "\tcurrent is :",self.stateMt.gX,self.stateMt.gY,self.stateMt.positionZ)
        self.goToPoint((tarX,tarY,tarZ), absoluteErrorMargin)     #+self.baseHeight
    
    '''
    from y co-ordinate of drone get in which row of field  drone is
    '''
    def getRowN(self,gY):
        if gY < 1:
            return 1
        elif gY > 61:
            return 61
        else:
            if abs(gY- (((gY-1)//4)*4 +1)) > abs(gY- (((gY-1)//4+1)*4 +1)):
                if gY- (((gY-1)//4+1)*4 +1) < 1:
                    return (gY-1)//4+2
                else:
                    return (gY-1)//4+1
            else:
                return   (gY-1)//4 + 1

    '''
    will stay at certain height above the box
    '''
    def onSpot(self):
        rate = rospy.Rate(20.0)
        #-------------------------------------------    onSpot ---------------------------------------------------------
        print( self.droneName,"on spot activated!!",self.stateMt.gX,self.stateMt.gY,self.stateMt.positionZ )

        
        gainX,gainY=0,0
        errorX,errorY=0,0
        vel = Twist()
        
        currZ = self.stateMt.positionZ
        
        self.stopTheDrone()
        
        '''
        checking if aruco is visible if it is not then waiting for sometime
        '''
        if not self.stateMt.isArucoMarkerVisible:
            ccc = 0
            self.goToPoint((self.stateMt.positionX,self.stateMt.positionY,3+self.baseHeight))
            for __ in range(15):
                rate.sleep()
                if self.stateMt.isArucoMarkerVisible:
                    self.firstDetected=self.stateMt.positionX,self.stateMt.positionY,self.stateMt.positionZ
                    break
                ccc+=1
            if ccc > 13:
                print("trying to fix it" , self.droneName)
                self.goToPoint(self.firstDetected)
                self.stopTheDrone()
                ccc = 0
                for __ in range(15):
                    rate.sleep()
                    if self.stateMt.isArucoMarkerVisible:
                        break
                    ccc +=1
                if ccc > 13 :
                    print("Not possible to find Aruco" , self.droneName)
                    return 'continue'
        
        
        errorX,errorY,sideOfSquare=self.stateMt.pixelErrorX,self.stateMt.pixelErrorY,self.stateMt.sideOfSquare

        #macking an intial guess from the given values about where the box can be
        # from this moving box little bit
        gX,gY,gZ=self.stateMt.gX,self.stateMt.gY,self.stateMt.positionZ
        tarX,tarY=0,0
        if (gY-1)%4 < 2.75 and (gY-1)%4 > 1.25:
            if gY < 1:
                tarY=1
            elif gY > 61:
                tarY=61
            else:
                if errorY > 0:
                    tarY=((gY-1)//4+1)*4 +1
                else:
                    tarY=((gY-1)//4)*4 +1
        else:
            if gY < 1:
                tarY=1
            elif gY > 61:
                tarY=61
            else:
                if abs(gY- (((gY-1)//4)*4 +1)) > abs(gY- (((gY-1)//4+1)*4 +1)):
                    tarY= ((gY-1)//4+1)*4 +1
                else:
                    tarY=  ((gY-1)//4)*4 +1
            tarX=gX+(gZ*errorX)/200

            print('target for this',self.droneName, 'is : ',tarX,tarY)
            #if gZ > 3.5:
            self.setPointGlobal((tarX,tarY,3),speed=2)
            currZ=3
        
        
        while  not rospy.is_shutdown():
            #calculating gains
            # error goes below 20 it will not change further
            
            if not self.stateMt.isArucoMarkerVisible:
                ccc = 0
                self.goToPoint((self.stateMt.positionX,self.stateMt.positionY,currZ))
                for __ in range(15):
                    rate.sleep()
                    if self.stateMt.isArucoMarkerVisible:
                        self.firstDetected=self.stateMt.positionX,self.stateMt.positionY,self.stateMt.positionZ
                        break
                    ccc+=1
                if ccc > 13:
                    print("trying to fix it" , self.droneName)
                    self.goToPoint(self.firstDetected)
                    self.stopTheDrone()
                    ccc = 0
                    for __ in range(15):
                        rate.sleep()
                        if self.stateMt.isArucoMarkerVisible:
                            break
                        ccc +=1
                    if ccc > 13 :
                        print("Not possible to find Aruco" , self.droneName)
                        return False
                    else :
                        continue
            
            if self.stateMt.isArucoMarkerVisible:
                errorX,errorY,sideOfSquare = self.stateMt.pixelErrorX,self.stateMt.pixelErrorY,self.stateMt.sideOfSquare
                errorZ = currZ-self.stateMt.positionZ
                if abs(errorX) < 30 : #or stopX: #40
                    gainX=0
                else:
                    gainX=0.005
                if abs(errorY) < 30 :#or stopY: #40
                    gainY=0
                else:
                    gainY=0.005
                vel.linear.x , vel.linear.y , vel.linear.z = errorX*gainX,errorY*gainY,errorZ*0.2

                #velocity should not exceed than 1m/s
                if vel.linear.x > 1:
                    vel.linear.x = 1
                elif vel.linear.x < -1:
                    vel.linear.x = -1
                if vel.linear.y > 1:
                    vel.linear.y = 1
                elif vel.linear.y < -1:
                    vel.linear.y = -1

                self.local_vel_pub.publish(vel)      #publishing velocity setpoints
                #print( self.stateMt.gX,self.stateMt.gY)
                rate.sleep()
                #now if drone is above aruco is specific range it will procced to land
                errorX,errorY,sideOfSquare = self.stateMt.pixelErrorX,self.stateMt.pixelErrorY,self.stateMt.sideOfSquare
                
                if abs(errorY) < 40 and abs(errorX) < 40 and abs(self.stateMt.velX)<0.05 and abs(self.stateMt.velY)<0.05:
                    print("break!!")
                    break
            
            if self.stateMt.moreThanOneAruco:
                self.stopTheDrone()
                errorX,errorY,sideOfSquare=self.stateMt.pixelErrorX,self.stateMt.pixelErrorY,self.stateMt.sideOfSquare
            
                print('more than 1 aruco!!!')
                #self.stopTheDrone()
                gX,gY,gZ=self.stateMt.gX,self.stateMt.gY,self.stateMt.positionZ
                tarX,tarY=0,0
                if gY < 1:
                    tarY=1
                elif gY > 61:
                    tarY=61
                else:
                    if errorY > -10:
                        tarY=((gY-1)//4+1)*4 +1
                    else:
                        tarY=((gY-1)//4)*4 +1
                tarX=gX+(gZ*errorX)/200
                print('target for this',self.droneName, 'is : ',tarX,tarY)
                #if gZ > 3.5:
                self.setPointGlobal((tarX,tarY,gZ-1),speed=2)
                currZ=3
                
        print(self.droneName , "on spot done", self.stateMt.gX,self.stateMt.gY)
        
        return True

    '''
    will pickUpTheAruco
    '''
    def pickingBox(self):
        #-----------------------      go above aruco -------------------------------------------------------------------
        vel = Twist()
        #self.goToPoint((self.stateMt.positionX,self.stateMt.positionY,3))
        #going down to land
        stopX,stopY,stopZ = False,False,False
        rate = rospy.Rate(20.0)

        if self.stateMt.positionZ > 3.2:
            self.goToPoint((self.stateMt.positionX,self.stateMt.positionY,3))

        while  not rospy.is_shutdown() :
            if self.stateMt.positionZ > 3.2:
                self.goToPoint((self.stateMt.positionX,self.stateMt.positionY,3))

            if not self.stateMt.isArucoMarkerVisible:
                ccc = 0
                for _ in range(10):
                    rate.sleep()
                    if self.stateMt.isArucoMarkerVisible:
                        break
                    ccc += 1 
                if ccc > 8:
                    self.goToPoint((self.stateMt.positionX,self.stateMt.positionY-0.5,self.stateMt.positionZ+1))
                    stopZ=False
                    if not self.stateMt.isArucoMarkerVisible:
                        ccc = 0
                        for _ in range(10):
                            rate.sleep()
                            if self.stateMt.isArucoMarkerVisible:
                                break
                            ccc += 1 
                        if ccc > 8:
                            return False

            errorX,errorY,sideOfSquare=self.stateMt.pixelErrorX,self.stateMt.pixelErrorY,self.stateMt.sideOfSquare
            errorZ= 90-sideOfSquare #for defdefault SDF 
            
            if abs(errorX) < 20 :
                gainX=0
                stopX=True
            elif abs(errorX) < 40:
                gainX=0.003
            else:
                gainX=0.005
                stopX=False
            
            if abs(errorY) < 20 :
                gainY=0
                stopY=True
            elif abs(errorY) < 40:
                gainY=0.003
            else:
                gainY=0.005
                stopY=False
            
            if sideOfSquare > 50:
                gainZ= -0.005
            else :
                gainZ= -0.01
            if sideOfSquare > 70 or stopZ:
                gainZ = 0
                stopZ=True

            vel.linear.x , vel.linear.y , vel.linear.z = errorX*gainX , errorY*gainY , errorZ*gainZ
            
            #print(  self.pixelErrorX , self.pixelErrorY,"\t", vel.linear.x , vel.linear.y , vel.linear.z)
            self.local_vel_pub.publish(vel)
            rate.sleep()

            errorX,errorY,sideOfSquare=self.stateMt.pixelErrorX,self.stateMt.pixelErrorY,self.stateMt.sideOfSquare

            if (abs(errorY) < 25  and abs(errorX) < 25  and (sideOfSquare >= 70 or stopZ)) or (stopX and stopY and stopZ):
                self.ArucoId = self.stateMt.arucoColorId
                self.stopTheDrone()
                print("the way we want!!" , self.droneName)
                self.isLandingOnBox=True
                break
            
               
        print( "right now position is :", self.stateMt.gX,self.stateMt.gY,self.stateMt.positionZ )

        # !!!!!!!!!!!!!!!!                         pickUPBox                        !!!!!!!!!!!!!!!!!!!!!!!!!!!
        backUpX,backUpY = self.stateMt.positionX, self.stateMt.positionY
        # -----------------------------           landing in offboard mode       ------------------------------------

        print(self.droneName, "LANDING")
        corX,corY = self.stateMt.positionX, self.stateMt.positionY
        
        rate= rospy.Rate(20.0)
        r2  = rospy.Rate(2.5)
        velX,velY,velZ=0,0,-0.5
        eX,eY = 0,0
        while not rospy.is_shutdown() :
            eX,eY = corX-self.stateMt.positionX , corY-self.stateMt.positionY
            if eX > 0.025:
                velX=eX - 0.01
            else:
                velX=0
            if eY > 0.025:
                velY=eY - 0.01
            else:
                velY=0

            if self.stateMt.isGripperCheck and not self.stateMt.isArucoMarkerVisible:
                velZ = -0.2
                vel.linear.x , vel.linear.y , vel.linear.z = velX,velY,velZ
                self.local_vel_pub.publish(vel)
                rate.sleep()
                
                #if vertical velocity goes below this (as expected is -0.2) it will considered as touching the surface and now box is ready to drop
                if self.stateMt.velZ > -0.1:
                    r2.sleep()
                    if self.stateMt.velZ > -0.1:
                        # !!!!!!!!!!!!!!! means drone have touched the surface !!!!!!!!!!!!!!!!!
                        break   
                
            else:
                velZ = -0.5
                vel.linear.x , vel.linear.y , vel.linear.z = velX,velY,velZ
                self.local_vel_pub.publish(vel)
                rate.sleep()
            if self.stateMt.extended_state.landed_state == 1 or self.stateMt.extended_state.landed_state == 0  :
                print("to pickUp",self.droneName, self.stateMt.extended_state.landed_state , "landed as expected",self.stateMt.gX,self.stateMt.gY,self.stateMt.positionZ )
                break

            #if no vertical velocity is deteced the it must be landed in wrong place so it will try to land again
            if self.stateMt.velZ > -0.08:
                print("!!!!!!!!!!!!! NOt Landed as expected unable to catch box !!!!!!!!!!!!!!!!!!!!!!!" , self.droneName)
                r2.sleep()
                if self.stateMt.velZ > -0.08:
                    break
        print("to pickUp",self.droneName, self.stateMt.extended_state.landed_state , "landed as expected",self.stateMt.gX, self.stateMt.gY,self.stateMt.positionZ  )

        # ----------------------------------------------------------------------------------------
        result = self.ofb_ctl.activateGripper(True,droneName=self.droneName)
        rate.sleep()
        if result.result == False:
            ccc = 0
            for _ in range(10):
                rate.sleep()
                result = self.ofb_ctl.activateGripper(True,droneName=self.droneName)
                if result.result:
                    break
                ccc +=1
            if ccc > 8:
                print(self.droneName,"Error!! Didn't land properly")
                self.goToPoint((backUpX,backUpY,3))
                t = self.onSpot()
                if t=='continue':
                    return False
                t = self.pickingBox()
                return t
        print("succes to catch gripper : ", self.droneName ,result, type(result.result))
        self.caughtAruco=True
        return True

    '''
    will drop the box at given location
    '''
    def droppingBox(self,droppingLocation):
        rate= rospy.Rate(15.0)

        if droppingLocation[1] < 1:
            self.setPointGlobal((droppingLocation[0],1,3.5+self.baseHeight),(0.5,0.2,0.2),speed=10)
        else:
            self.setPointGlobal((droppingLocation[0]+1,61,3.5+self.baseHeight),(1,1,0.2),speed=10)

        self.setPointGlobal((droppingLocation[0],droppingLocation[1],3.5+self.baseHeight))
        rate.sleep()
        self.setPointGlobal((droppingLocation[0],droppingLocation[1],3.5+self.baseHeight),speed=3)
        
        print()
        print(self.droneName, "LANDING")
        
        if droppingLocation[1] < 1:
            #-------------------------------------- staying on spot       -------------------------------
            #-------------------------------------------     landing on floor to drop -------------------------------------------------------------------------
            self.setPointGlobal((droppingLocation[0],droppingLocation[1],1.9),absoluteErrorMargin=(1,1,0.2))
            self.isFrom = 'blue'
        else:
            self.setPointGlobal((droppingLocation[0],droppingLocation[1],1.9),absoluteErrorMargin=(1,1,0.2))
            self.isFrom = 'red'
           
        #------------------       dropping the box                 ---------------------------------------------
        result = self.ofb_ctl.activateGripper(False,droneName=self.droneName)
        rate.sleep()
        print("dropping the box : ", self.droneName ,result, type(result.result))
        print('dropping error',droppingLocation[0]-self.stateMt.gX,droppingLocation[1]- self.stateMt.gY)
        self.armingDrone()

        

        self.goToPoint((self.stateMt.positionX,self.stateMt.positionY,3+self.baseHeight))
        if self.stateMt.gY < 1:
            self.setPointGlobal((self.stateMt.gX,1,3+self.baseHeight),(1,1,0.2),speed=7)
        else:
            self.setPointGlobal((self.stateMt.gX,61,3+self.baseHeight),(1,1,0.2),speed=7)


#this will control multiple drones parallely
'''
This is the main class will control all the drones parallely

Will take location of truck_cells as input
'''
class control_multiple_drone:
    def __init__(self,truck_cells, truck_heights,ofb_ctl=None):
        #color and location of this boxes are not known
        #here index will represent row
        #and the value of that row will represent number of boxes in that row

        #i.e if self.unknownBoxes[1] = 3 means their are three unknown boxes in first row
        self.unknownBoxes = np.zeros(16)         
        
        self.truck_cells = truck_cells
        self.truck_heights = truck_heights
        
        self.ofb_ctl=ofb_ctl
        #rowsTaken by drones
        #this is to avoid two drone flying in single row
        self.rowsTaken = {} 
        #will hold all the drone's single_drone_control object
        self.drones_object = []
        #will hold threads of drones
        self.Threads = []                     #will store threads of drones

        #from which location drone should start if is from blue from 0 to 60 
        # in this example drone is starting from 0 to 60
        self.fromBlue =np.ones(16)*-1
        #from which location drone should start if it is from red i.e from 45 to 0 
        #in this example drone is starting from 45 to 0 
        self.fromRed = np.ones(16)*45
        
        #status means
        #if self.boxStatus[1] = [('red', 0),('unknown',-1),('picked',8)] shows
        #their are three boxes in 1 st row out of which red is at locaiton 0 and the next box unkown and third is being picked up from 8
        self.boxStatus =  np.empty(16, dtype=object)
        for _ in range(16):
            self.boxStatus[_] = list()

        #is self.blueBoxes[1] = [-1,17,13]
        #this means in first row their are three red boxes at location -1,17,13
        #i.e location of boxes are (-1,1),(17,1),(13,1)
        self.blueBoxes =  np.empty(16, dtype=object)
        for _ in range(16):
            self.blueBoxes[_] = list()
        
        #just like blueBoxes it will store red boxes
        self.redBoxes =  np.empty(16, dtype=object)
        for _ in range(16):
            self.redBoxes[_] = list()
        
        #callback to get know where the new box have come
        rospy.Subscriber("/spawn_info",UInt8, self.setRowsCallback) 
    
    '''
    will return the row in which the point in
    '''
    def getRowN(self,gY):
        if gY <= 1:
            return 1
        elif gY >= 60:
            return 15
        else:
            if abs(gY- (((gY-1)//4)*4 +1)) > abs(gY- (((gY-1)//4+1)*4 +1)):
                if gY- (((gY-1)//4+1)*4 +1) < 1:
                    return int((gY-1)//4+2)
                else:
                    return int((gY-1)//4+1)
            else:
                return   int((gY-1)//4 + 1)
    
    #callbackFunction 
    def setRowsCallback(self,data):
        self.unknownBoxes[data.data] += 1
        self.handleBoxStatus(-1,(data.data - 1)*4 +1,  'unknown')

    '''
    will handle self.boxStatus variable
    
    inputs: 1.current location, 
            2. status i.e. whether the box is red,blue,unknown,picked 
            3. from where the drone is coming, i.e 'blue' if going from 0-60 anf red if coming from 60-0
            4. previousNumberOfBoxes
            
    Working:
    will update the list in self.boxStatusVariable
    and add the new status of box we have found
    '''
    def handleBoxStatus(self,gX,gY,status, isFrom=None, previousNumberOfBoxes=0):
        
        rowNumber = self.getRowN(gY)
        print(gY, rowNumber)
        print(status,"for :" , rowNumber, "Box status before : ", self.boxStatus[rowNumber])
        if status == 'unknown':
            self.boxStatus[rowNumber].append(('unknown',-1))
        else:
            remaining=[]
            #this is done ,other wise code would fail as we will consider that other box as well
            if previousNumberOfBoxes != 0 :  
                boxStatus = self.boxStatus[rowNumber][:previousNumberOfBoxes]
                remaining = self.boxStatus[rowNumber][previousNumberOfBoxes:]
            else:
                boxStatus = self.boxStatus[rowNumber]
            if isFrom != None :
                l = []
                if isFrom == 'blue' or isFrom == '':
                    bo = True
                    for _ in boxStatus:
                        if _[0] == 'unknown' and bo:
                            l.append((status,gX))
                            bo = False
                        else:
                            l.append(_)
                else :
                    bo = True
                    le = len(boxStatus)
                    for __ in range(le):
                        _ = boxStatus.pop()
                        if _[0] == 'unknown' and bo:
                            l.append((status,gX))
                            bo = False
                        else:
                            l.append(_)
                    l.reverse()
                self.boxStatus[rowNumber] = l[:] + remaining
            print("for :" , rowNumber, "Box status after : ", self.boxStatus[rowNumber])
            self.unknownBoxes[rowNumber] -= 1
        self.handleFromBlue(gX,self.getRowN(gY))
        self.handleFromRed(gX,self.getRowN(gY))
                
    def handleFromBlue(self,gX,rowNumber):
        #print("self.fromBlue before " , rowNumber , "\t" , self.fromBlue[rowNumber])
        l = self.boxStatus[rowNumber][:]
        ans=1
        for _ in l:
            if _[0] == 'unknown' :
                break
            elif _[0] == 'picked':
                ans = _[1] + 5
            else:
                ans = _[1] + 5
        for _ in self.redBoxes[rowNumber]:
            if abs(_-ans) < 4:
                return
        for _ in self.blueBoxes[rowNumber]:
            if abs(_-ans) < 4 :
                return
        self.fromBlue[rowNumber] = ans

    def handleFromRed(self,gX,rowNumber):
        #print("self.fromRed before " , rowNumber , "\t" , self.fromRed[rowNumber])
        l = self.boxStatus[rowNumber][:]
        ans = 46
        for _ in range(1,len(l)+1):
            _ = -1*_
            curr = l[_]
            if curr[0] == 'unknown' :
                break
            elif curr[0] == 'picked':
                ans = curr[1] - 7
            else:
                ans = curr[1] - 8
        for _ in self.redBoxes[rowNumber]:
            if abs(_-ans) < 4:
                return
        for _ in self.blueBoxes[rowNumber]:
            if abs(_-ans) < 4 :
                return
                
        if self.fromBlue[rowNumber] > ans:
            return
        self.fromRed[rowNumber] = ans 
        
    def handleRedAruco(self, gX,gY, pixelErrorX=None, z=4,isFrom='blue',numberOfBoxes=0):
        y=self.getRowN(gY)
        if pixelErrorX == None:
            x = gX 
        else:
            x=gX + (z*pixelErrorX)//200
        for _ in self.redBoxes[y]:
            if abs(_-x) < 4:
                print("Already boycotted!!",self.redBoxes[y])
                return
        
        self.redBoxes[y].append(x)
        #self.unknownBoxes[y] -= 1
        #print("handleBoxStatus red",y)
        self.handleBoxStatus(x,gY,'red',isFrom,numberOfBoxes)
    
    def handleBlueAruco(self, gX,gY, pixelErrorX=None, z=4,isFrom='red',numberOfBoxes=0):
        y=self.getRowN(gY)
        if pixelErrorX == None:
            x = gX 
        else:
            x=gX + (z*pixelErrorX)//200
        for _ in self.blueBoxes[y]:
            if abs(_-x) < 4:
                return
        
        self.blueBoxes[y].append(x)
        #self.unknownBoxes[y] -= 1
        #print("handleBoxStatus blue")
        self.handleBoxStatus(x,gY,'blue',isFrom,numberOfBoxes)

    '''
    this will give closes location from the drone where we will go to find box
    '''
    def closest(self, gX,gY, edrone, printAll = False):
        minDis = 85
        currX, currY = gX,gY
        ans = [0,0]
        def dis(x,y,minD=None,ans=None):
            if minD > ((x-currX)**2+(y-currY)**2)**0.5 and ((x-currX)**2+(y-currY)**2)**0.5 > 5 : 
                ans = [x,y]
                minD=  ((x-currX)**2+(y-currY)**2)**0.5
            return minD,ans

        if len(edrone.anotherDrones) != 0:
            rowAnotherDrone = self.rowsTaken[edrone.anotherDrones[0].droneName]
        else:
            rowAnotherDrone = -1

        for _ in range(16):
            if _ == rowAnotherDrone:
                continue
            if self.unknownBoxes[_] > 0:
                minDis,ans=dis(self.fromBlue[_],(_-1)*4+1,minDis,ans)
        edrone.isFrom = 'blue'
        if printAll:
            print(minDis,ans)
        prev = minDis
        for _ in range(16):
            if _ == rowAnotherDrone:
                continue
            if self.unknownBoxes[_] > 0:
                minDis,ans=dis(self.fromRed[_] ,(_-1)*4+1,minDis,ans)
        if minDis < prev :
            edrone.isFrom = 'red'

        if printAll:
            print(minDis,ans)
        if self.unknownBoxes.sum() > 0 :
            for _ in range(16):  
                for x in self.blueBoxes[_]:
                    currX, currY = x,(_-1)*4+1
                    if ((currX-14.2)**2 + (currY+1)**2)  < ((currX-57)**2 + (currY-60)**2) + 10 and self.unknownBoxes[_] > 0:
                        minDis,ans=dis(x,(_-1)*4+1,minDis,ans)
                for x in self.redBoxes[_]:
                    currX, currY = x,(_-1)*4+1
                    if ((currX-14.2)**2 + (currY+1)**2) + 10 > ((currX-57)**2 + (currY-60)**2) and self.unknownBoxes[_] > 0:
                        minDis,ans=dis(x,(_-1)*4+1,minDis,ans)
        else: 
            for _ in range(16):  
                for x in self.blueBoxes[_]:
                    minDis,ans=dis(x,(_-1)*4+1,minDis,ans)
                for x in self.redBoxes[_]:
                    minDis,ans=dis(x,(_-1)*4+1,minDis,ans)
        if printAll:
            print(minDis,ans)
        self.rowsTaken[edrone.droneName] = self.getRowN(ans[1])
        return ans 
    

    '''
    if detected aruco is not sufficiently close to it's color truck 
    then we will save the aruco for later
    '''
    def shouldBoycott(self,edrone,numberOfBoxes):
        rate=rospy.Rate(20)
        currX, currY = edrone.stateMt.gX,edrone.stateMt.gY
        print("Should Boycott at row : " , self.getRowN(currY))
        color = ''
        if edrone.stateMt.arucoColorId == 1:
            color = 'red'
        elif edrone.stateMt.arucoColorId ==2:
            color = 'blue'
        else: 
            #to make sure the color of box
            for _ in range(5):
                if edrone.stateMt.arucoColorId == 1:
                    color = 'red'
                    break
                elif edrone.stateMt.arucoColorId ==2:
                    color = 'blue'
                    break
                rate.sleep()

        if color == 'red':
            #checking if it is valid range to pick up?
            if ((currX-14.2)**2 + (currY+1)**2) +10 < ((currX-57)**2 + (currY-60)**2) :
                #calling this function to know that are we repeating the box or not
                self.handleRedAruco(currX,currY, edrone.stateMt.pixelErrorX, edrone.stateMt.positionZ,edrone.isFrom,numberOfBoxes)
                print("Boycott : ", color )
                return True
        elif color=='blue':
            #checking if it is valid range to pick up?
            if ((currX-14.2)**2 + (currY+1)**2) > ((currX-57)**2 + (currY-60)**2) + 10 :
                #calling this function to know that are we repeating the box or not
                self.handleBlueAruco(currX,currY,edrone.stateMt.pixelErrorX, edrone.stateMt.positionZ,edrone.isFrom, numberOfBoxes)
                print("Boycott : ", color )
                return True

        return False    
    
    '''
    dropping location of aruco
    '''
    def dropLocation(self, color):           
        xy = self.truck_cells[color].pop()
        height= 1.7                   #self.truck_heights[droneName][color]
        return xy,height
    
    #this will create drone objects
    #within this it will check whethers all subscribers are ready so that drone could go in offboard mode
    def createDroneObjects(self,drones=['edrone1','edrone0'], hompose=[(-1,61),(-1,1)]):
        self.drones_object.clear()
        droneName=''
        homepose= [0,0]
        edrone=None
        for _ in range(len(drones)):
            droneName=drones[_]
            homepose=hompose[_]
            self.drones_object.append( single_drone_control(stateMoniter(droneName,homepose),droneName,homepose,height= _ ,ofb_ctl=self.ofb_ctl) )
            self.rowsTaken[droneName] = -1 
        for _ in range(len(drones)):
            edrone=self.drones_object[_]
            for __ in range(len(drones)):
                if _ != __:
                    edrone.anotherDrones.append(self.drones_object[__])

    def goOnPath(self, edrone,numberOfBoxes):

        print("\n\tstarting goOnPath\t\n")
        rate = rospy.Rate(20)
        pos=PoseStamped()
        
        closest = self.closest(edrone.stateMt.gX,edrone.stateMt.gY, edrone ,printAll=True)
        print("CLosest :", closest)
        if  closest[1] > edrone.stateMt.gY + 5:
            edrone.setPointGlobal((closest[0],closest[1]-8,3+edrone.baseHeight),(1,1,0.2),speed=10)
            rate.sleep()
            edrone.setPointGlobal((closest[0],closest[1],3+edrone.baseHeight),speed=5)
            rate.sleep()
            edrone.setPointGlobal((closest[0],closest[1],3+edrone.baseHeight),speed=3)
        elif closest[1] < edrone.stateMt.gY - 5:
            edrone.setPointGlobal((closest[0],closest[1]+8,3+edrone.baseHeight),(1,1,0.2),speed=10)
            rate.sleep()
            edrone.setPointGlobal((closest[0],closest[1],3+edrone.baseHeight),speed=5)
            rate.sleep()
            edrone.setPointGlobal((closest[0],closest[1],3+edrone.baseHeight),speed=3)
        else:
            edrone.setPointGlobal((closest[0],closest[1],3+edrone.baseHeight),(1,1,0.2),speed=8)
            rate.sleep()
            edrone.setPointGlobal((closest[0],closest[1],3+edrone.baseHeight),speed=3)
            rate.sleep()
        
        if edrone.isFrom == 'red':
            target=(0,closest[1])
        else:
            target=(60,closest[1])
        print("going to     :",target)
        
        tarX=target[0]-edrone.homepose[0] 
        tarY=target[1]-edrone.homepose[1]
        tarZ=3+edrone.baseHeight
        pos.pose.position.x, pos.pose.position.y, pos.pose.position.z  = tarX,tarY,tarZ
        currX,currY,currZ=edrone.stateMt.positionX,edrone.stateMt.positionY,edrone.stateMt.positionZ
        
        rate.sleep()
        if self.shouldBoycott(edrone,numberOfBoxes):
            print(self.boxStatus[self.getRowN(edrone.stateMt.gY)])
            return False,-1

        numberOfBoxes = len(self.boxStatus[self.getRowN(edrone.stateMt.gY)])

        if edrone.stateMt.isArucoMarkerVisible:
            edrone.firstDetected = (edrone.stateMt.positionX,edrone.stateMt.positionY,edrone.stateMt.positionZ)
            t = self.shouldBoycott(edrone,numberOfBoxes)
            if t:
                edrone.stateMt.isArucoMarkerVisible=False
                edrone.stopTheDrone()
                return False,-1
            else: 
                edrone.stopTheDrone()
                tt = edrone.onSpot()
                return tt,numberOfBoxes
            
            
        else:
            for _ in range(5):
                if edrone.stateMt.isArucoMarkerVisible:
                    edrone.firstDetected = (edrone.stateMt.positionX,edrone.stateMt.positionY,edrone.stateMt.positionZ)
                    t = self.shouldBoycott(edrone,numberOfBoxes)
                    if t:
                        edrone.stateMt.isArucoMarkerVisible=False
                        edrone.stopTheDrone()
                        return False,-1
                    else: 
                        edrone.stopTheDrone()
                        tt = edrone.onSpot()
                        return tt,numberOfBoxes
                rate.sleep()
        edrone.ofb_ctl.set_parameter('MPC_XY_VEL_MAX',set_param_value_real=5,droneName=edrone.droneName)
        rate.sleep()
        print("going to point !! " , target)
        edrone.local_pos_pub.publish(pos)
        rate.sleep()
        while  not rospy.is_shutdown():
            if not edrone.stateMt.state.armed or not edrone.stateMt.state.mode=="OFFBOARD":
                edrone.armingDrone()
            if edrone.stateMt.isArucoMarkerVisible:
                edrone.firstDetected = (edrone.stateMt.positionX,edrone.stateMt.positionY,edrone.stateMt.positionZ)
                edrone.stopTheDrone()
                t = self.shouldBoycott(edrone,numberOfBoxes)
                if t:
                    edrone.stateMt.isArucoMarkerVisible=False
                    #edrone.stopTheDrone()
                    return False,-1
                else: 
                    #edrone.stopTheDrone()
                    tt = edrone.onSpot()
                    return tt,numberOfBoxes
            currX,currY,currZ=edrone.stateMt.positionX,edrone.stateMt.positionY,edrone.stateMt.positionZ
            if (abs(tarX-currX) < 0.5 and abs(tarY-currY) < 0.5 and abs(tarZ-currZ)<0.2):
                print("Reachead !!! at ",edrone.stateMt.gX, edrone.stateMt.gY, edrone.stateMt.positionZ)
                break
            rate.sleep()

        print("\tending goOnPath\t")
        return False,-1     

    def goOnPath2(self,edrone,numberOfBoxes):
        rate = rospy.Rate(20)
        pos=PoseStamped()
        
        closest = self.closest(edrone.stateMt.gX,edrone.stateMt.gY, edrone )
        edrone.setPointGlobal((closest[0],closest[1],3+edrone.baseHeight),(1,1,0.2),speed=10)
        rate.sleep()
        edrone.setPointGlobal((closest[0],closest[1],3+edrone.baseHeight),speed=3)

        if edrone.isFrom == 'red':
            target=(0,closest[1])
        else:
            target=(60,closest[1])

        tarX=target[0]-edrone.homepose[0] 
        tarY=target[1]-edrone.homepose[1]
        tarZ=3+edrone.baseHeight
        pos.pose.position.x, pos.pose.position.y, pos.pose.position.z  = tarX,tarY,tarZ
        currX,currY,currZ=edrone.stateMt.positionX,edrone.stateMt.positionY,edrone.stateMt.positionZ
        
        edrone.ofb_ctl.set_parameter('MPC_XY_VEL_MAX',set_param_value_real=5,droneName=self.droneName)

        if edrone.stateMt.isArucoMarkerVisible:
            edrone.firstDetected = (edrone.stateMt.positionX,edrone.stateMt.positionY,edrone.stateMt.positionZ)
            self.stopTheDrone()
            tt = edrone.onSpot()
            return tt
        else: 
            self.local_pos_pub.publish(pos)
            rate.sleep()
            while  not rospy.is_shutdown():
                if not self.stateMt.state.armed or not self.stateMt.state.mode=="OFFBOARD":
                    self.armingDrone()
                if self.stateMt.isArucoMarkerVisible:
                    edrone.firstDetected = (edrone.stateMt.positionX,edrone.stateMt.positionY,edrone.stateMt.positionZ)
                    self.stopTheDrone()
                    tt = edrone.onSpot()
                    return tt
                currX,currY,currZ=edrone.stateMt.positionX,edrone.stateMt.positionY,edrone.stateMt.positionZ
                if (abs(tarX-currX) < 0.5 and abs(tarY-currY) < 0.5 and abs(tarZ-currZ)<0.2):
                    print("Reachead !!! at ",edrone.stateMt.gX, edrone.stateMt.gY, edrone.stateMt.positionZ)
                    break
                rate.sleep()
                
        return False  
         
    #this is the main function
    def mainFun(self, edrone):
        rate=rospy.Rate(20.0)
        #edrone.ofb_ctl.set_parameter('MPC_XY_VEL_MAX',set_param_value_real=10.0,droneName=self.droneName)
        
        edrone.armingDrone()
        edrone.setPointGlobal((edrone.stateMt.gX,edrone.stateMt.gY,3+edrone.baseHeight))   #takeofff !!!!
        while self.unknownBoxes.sum() > 0 : 
            numberOfBoxesP = len(self.boxStatus[self.getRowN(edrone.stateMt.gY)])
            tt,numberOfBoxes = self.goOnPath(edrone, numberOfBoxes = len(self.boxStatus[self.getRowN(edrone.stateMt.gY)]))
            if numberOfBoxes == -1:
                numberOfBoxes = numberOfBoxesP
            if tt:
                edrone.pickingBox()
                if edrone.ArucoId == 1:
                    color='red'
                else:
                    color='blue'
                if edrone.caughtAruco:
                    xy,height= self.dropLocation(color)
                    self.handleBoxStatus(edrone.stateMt.gX,edrone.stateMt.gY,'picked',edrone.isFrom,numberOfBoxes)
                    edrone.setPointGlobal((edrone.stateMt.gX,edrone.stateMt.gY,3+edrone.baseHeight))   #takeofff !!!!
                    edrone.droppingBox(xy)
            
        while True :
            tt = self.goOnPath2(edrone, numberOfBoxes = len(self.boxStatus[self.getRowN(edrone.stateMt.gY)]))
            if tt:
                edrone.pickingBox()
                if edrone.ArucoId == 1:
                    color='red'
                else:
                    color='blue'
                if edrone.caughtAruco:
                    xy,height= self.dropLocation(color)
                    self.handleBoxStatus(edrone.stateMt.gX,edrone.stateMt.gY,'picked',edrone.isFrom,numberOfBoxes)
                    edrone.setPointGlobal((edrone.stateMt.gX,edrone.stateMt.gY,3+edrone.baseHeight))   #takeofff !!!!
                    edrone.droppingBox(xy)
            
            t = True
            for __ in self.redBoxes:
                if len(__) > 0 :
                    continue
            ttt = True
            for __ in self.blueBoxes:
                if len(__) > 0 :
                    continue
            if t and ttt:
                break
    
    #this will create threads and also start them
    def createThreads(self):
        for _ in self.drones_object:
            t = threading.Thread(target=self.mainFun,args=(_,))
            self.Threads.append(t)
            t.start()

    def executeThreads(self): #currently this is not in use but it can if we want to activate it in this way
        for _ in self.Threads:
            _.start()


def main():
    droneNames=['edrone0','edrone1'] 
    x1=14.2
    x2=15.8
    blue_cells=[]
    for _ in range(2):
        y=-7.5
        for __ in range(4):
            blue_cells.append([x1,y])
            blue_cells.append([x2,y])
            y += 0.9
        x1+=0.8
        x2+=0.8

    x1=56.9
    x2=56.9 + 1.6
    red_cells=[]
    for _ in range(2):
        y = 64.6
        for __ in range(4):
            red_cells.append([x1,y])
            red_cells.append([x2,y])
            y += 0.9
        x1+=0.8
        x2+=0.8

    truck_cells = {'blue':blue_cells,'red':red_cells}
    truck_heights= {'blue':1.7 , 'red':1.7}

    ofb_ctl=offboard_control()
    control_d = control_multiple_drone(  truck_cells, truck_heights,ofb_ctl=ofb_ctl)   #drones=['edrone0'], hompose=[(-1,1)]
    control_d.createDroneObjects(drones=['edrone1','edrone0'], hompose=[(-1,61),(-1,1)]) #drones=['edrone1','edrone0'], hompose=[(-1,61),(-1,1)]
    control_d.createThreads()
    #print(control_d.Threads, len(control_d.Threads)  )
    #print(control_d.rows, len(control_d.rows)  )
    #control_d.executeThreads()
    

    
if __name__ == '__main__':
    try:
        main()
    except rospy.ROSInterruptException:
        print("Errror!!")
        pass



 