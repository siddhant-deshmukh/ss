#!/usr/bin/env python3

from re import S
import rospy
from geometry_msgs.msg import *
from mavros_msgs.msg import *
from mavros_msgs.srv import *
from gazebo_ros_link_attacher.srv import *
from rospy.impl.transport import BIDIRECTIONAL
from sensor_msgs.msg import Image
from cv_bridge import CvBridge, CvBridgeError
import cv2
import numpy as np
import threading



#this will hold methods needed to operate drone in offboard
#like arming, changing drone mode, activate gripper, setting parameters
class offboard_control:
    def __init__(self,droneName='edrone1'):
        # Initialise rosnode
        rospy.init_node('multidrone', anonymous=True)
        self.droneName=droneName
    def setArm(self, value=True):
        # Calling to /mavros/cmd/arming to arm the drone and print fail message on failure
        rospy.wait_for_service(self.droneName+'/mavros/cmd/arming')  # Waiting untill the service starts 
        try:
            armService = rospy.ServiceProxy(self.droneName+'/mavros/cmd/arming', mavros_msgs.srv.CommandBool) # Creating a proxy service for the rosservice named /mavros/cmd/arming for arming the drone 
            result=armService(value)
            print(result)
        except rospy.ServiceException as e:
            print ("Service arming call failed: %s"%e)

        # Similarly delacre other service proxies 
    def offboard_set_mode(self):
        # Call /mavros/set_mode to set the mode the drone to OFFBOARD
        # and print fail message on failure
        rospy.wait_for_service(self.droneName+'/mavros/set_mode')
        try:
            setMode=rospy.ServiceProxy(self.droneName+'/mavros/set_mode',mavros_msgs.srv.SetMode)
            result=setMode(custom_mode='OFFBOARD')
            #print("set mode to offboard")
            print(result)
        except rospy.ServiceException as e:
            print ("Service offvoard set_mode call failed: %s"%e)
                
    def setAutoLandMode(self):
        rospy.wait_for_service(self.droneName+'/mavros/set_mode')
        try:
            flightModeService = rospy.ServiceProxy(self.droneName+'/mavros/set_mode', mavros_msgs.srv.SetMode)
            flightModeService(custom_mode='AUTO.LAND')
        except rospy.ServiceException as e:
            print("service set_mode call failed: %s. Autoland Mode could not be set."%e)

    def set_parameter(self,paramId='COM_RCL_EXCEPT',set_param_value_integer=2,set_param_value_real=2.0):
        rospy.wait_for_service(self.droneName+'/mavros/param/set')
        try:

            setParams=rospy.ServiceProxy(self.droneName+'/mavros/param/set',mavros_msgs.srv.ParamSet)
            paramValue= ParamValue()
            paramValue.real=set_param_value_real
            response=setParams(param_id=paramId,value=paramValue)
            #print("Done here!!")
            #print("setting parameter", paramId , response.success , response.value.real)
        except rospy.ServiceException as e:
            print("Service  set_Parameters call failed: %s"%e)
    def activateGripper(self, setValue=True):
        print("trying to activate Gripper")
        rospy.wait_for_service(self.droneName+"/activate_gripper")
        try:
            gripper = rospy.ServiceProxy(self.droneName+'/activate_gripper', Gripper )
            result = gripper(activate_gripper=setValue)
            print("result of activaGripper : " , result)
            return result
        except rospy.ServiceException as e:
            print("service activaGripper call failed: %s. Autoland Mode could not be set."%e)
   
#this will hold current state of drone
#like it's position, velocity, is gripper ready, is aruco visible
class stateMoniter:
    def __init__(self , droneName, homepose):
        self.state = State()
        # Instantiate a setpoints message
        self.positionX=0
        self.positionY=0
        self.positionZ=0

        self.gX = 0              #co-ordinates of drone in global frame
        self.gY = 0

        self.droneName = droneName               #edrone/edrone1
        self.homepose = homepose                #home position of drone in global frame

        self.velX=0
        self.velY=0
        self.velZ=0                        #velocity of drone

        self.isGripperCheck=False
        self.img = np.empty([]) # This will contain your image frame from camera
        self.bridge = CvBridge()

        self.picture_count=0
        self.isArucoMarkerVisible=False         #this shows wither Aruco Marker is their or not
        
        #this will save the errors
        self.pixelErrorX=0               #x distance between the center of caemra and center of AruCo
        self.pixelErrorY=0               #y distance between the center of caemra and center of AruCo
        self.sideOfSquare =1                  #x distance between two corners of AruCo 1st and 4th
        
        self.extended_state = ExtendedState()

        topic_name=['ext_state', 'local_pos','state','mission_wp'] #'alt'
        self.sub_topics_ready = {}
        for _ in topic_name:
            self.sub_topics_ready[_] = False
        
    def stateCb(self, msg):
        # Callback function for topic /mavros/state
        self.state = msg

        if not self.sub_topics_ready['state'] : #and msg.connected
            self.sub_topics_ready['state'] = True
    def setPositionCallback(self ,data):
        #to keep track of drone position
        self.positionX=data.pose.position.x 
        self.positionY=data.pose.position.y 
        self.positionZ=data.pose.position.z

        self.gX=data.pose.position.x + self.homepose[0]
        self.gY=data.pose.position.y + self.homepose[1]

        if not self.sub_topics_ready['local_pos']:
            self.sub_topics_ready['local_pos'] = True
    def setVelocityCallback(self,data):
        #to keep tarck of drone velocity
        self.velX=data.twist.linear.x 
        self.velY=data.twist.linear.y 
        self.velZ=data.twist.linear.z
    def gripperCheck(self, data):
        #to check if gripper is ready to activate or not
        if data.data == 'True':
            self.isGripperCheck=True
        else:
            self.isGripperCheck=False
    def extended_state_callback(self, data):
        self.extended_state = data

        if not self.sub_topics_ready['ext_state']:
            self.sub_topics_ready['ext_state'] = True
    def mission_wp_callback(self,data):                   #this is only to check if drone is ready to go in offboard mode
        if not self.sub_topics_ready['mission_wp']:
            self.sub_topics_ready['mission_wp'] = True
    def imageCallBack(self,img):
        try:
            img = self.bridge.imgmsg_to_cv2(img, "bgr8")               # Converting the image to OpenCV standard image

            Detected_ArUco_markers = {}
            #detecting aruco and its corners
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            aruco_dict = cv2.aruco.Dictionary_get(cv2.aruco.DICT_5X5_250)
            parameters = cv2.aruco.DetectorParameters_create()
            corners, ids, _ = cv2.aruco.detectMarkers(gray, aruco_dict, parameters = parameters)
            
            if len(corners)==0 :    
                self.isArucoMarkerVisible=False
            else:
                cXY=(int((corners[0][0][0][0] + corners[0][0][2][0])//2),int((corners[0][0][0][1] + corners[0][0][2][1])//2))
                if cXY[1] > 80 and cXY[1] < 320:
                    self.isArucoMarkerVisible=True

            height, width, _ = img.shape
            if  len(corners)!=0 :
                count=0
                for _ in ids[0]:
                    Detected_ArUco_markers[_] = corners[count]
                    count+=1
            
                markerCorner=corners[0]
                cXY=(int((markerCorner[0][0][0] + markerCorner[0][2][0])//2),int((markerCorner[0][0][1] + markerCorner[0][2][1])//2))
                cXY=(int((markerCorner[0][0][0] + markerCorner[0][2][0])//2),int((markerCorner[0][0][1] + markerCorner[0][2][1])//2))
                
                #how many pixels are their in side of Aruco 
                #this will tell us how close drone is frome Aruco in height
                self.sideOfSquare=abs(int(((markerCorner[0][3][0] - markerCorner[0][0][0])**2+(markerCorner[0][3][1] - markerCorner[0][0][1])**2)**0.5))
                
                self.pixelErrorX=(cXY[0]-width//2)
                self.pixelErrorY=(height//2)-(cXY[1]- (1.25*self.sideOfSquare) - 13.5) #for default SDF file
                #because camera is not at center position of drone self.pixelError is modified
        except CvBridgeError as e:
            print(e)
            return


#this class will contain all methods to control drone
class single_drone_control:
    def __init__(self, stateMt, droneName='edrone1',homepose=(-1,1) ,cameraName="iris_1"):
        #this function can be used to arm the drone or setting mode to OFFBOARD mode

        self.droneName=droneName
        self.cameraName=droneName
        self.ofb_ctl=offboard_control(droneName)
        self.stateMt=stateMt
        self.homepose=homepose

        self.firstDetected = None
        #publisher
        self.local_pos_pub = rospy.Publisher(self.droneName+'/mavros/setpoint_position/local', PoseStamped, queue_size=10)
        self.local_vel_pub = rospy.Publisher(self.droneName+'/mavros/setpoint_velocity/cmd_vel_unstamped',Twist, queue_size=10)
        #subscriber
        rospy.Subscriber(self.droneName+"/mavros/state",State, self.stateMt.stateCb)
        rospy.Subscriber(self.droneName+"/mavros/local_position/pose", PoseStamped, self.stateMt.setPositionCallback)
        rospy.Subscriber(self.droneName+"/gripper_check",std_msgs.msg.String , self.stateMt.gripperCheck )
        
        rospy.Subscriber(self.cameraName+"/camera/image_raw",Image,self.stateMt.imageCallBack)
        rospy.Subscriber(self.droneName+"/mavros/local_position/velocity_local",TwistStamped,self.stateMt.setVelocityCallback)
        rospy.Subscriber(self.droneName+'/mavros/extended_state',ExtendedState, self.stateMt.extended_state_callback)
        
        rospy.Subscriber(self.droneName+'/mavros/mission/waypoints', WaypointList, self.stateMt.mission_wp_callback)

        #will wait for topics to be ready
        if self.wait_for_topics(60):
            print("Ready to fly!!" , self.droneName)
        else:
            print("Failed to fly!!!" ,self.droneName)
        
        #setting parameter
        self.ofb_ctl.set_parameter('COM_DISARM_LAND',set_param_value_real= 10.0)
        self.ofb_ctl.set_parameter('MPC_XY_VEL_MAX',set_param_value_real=10.0)  #to control maximum automatic speed of Drone                                                                  #will be good if kept less than 5
        self.ofb_ctl.set_parameter('MPC_LAND_ALT1',set_param_value_real=3.0)
        self.ofb_ctl.set_parameter('MPC_LAND_ALT2',set_param_value_real=1.2)
    
    #to arm drone if it is not arm or to go in offboard mode if it is not in offboard mode
    def wait_for_topics(self, timeout):
        
        rospy.loginfo("waiting for subscribed topics to be ready")
        loop_freq = 5  # Hz
        rate = rospy.Rate(loop_freq)
        simulation_ready = False
        for i in range(timeout * loop_freq):
            if all(value for value in self.stateMt.sub_topics_ready.values()):
                simulation_ready = True
                break
            try:
                rate.sleep()
            except rospy.ROSException as e:
                self.fail(e)
        return simulation_ready

    #this will arm drone if it is not armed and set mode to offboard if it is not in offboard mode
    def armingDrone(self):
        pos =PoseStamped()
        pos.pose.position.x = 0
        pos.pose.position.y = 0
        pos.pose.position.z = 0

        rate = rospy.Rate(20.0)
        if self.stateMt.state.mode != "OFFBOARD":
            for i in range(100):
                self.local_pos_pub.publish(pos)
                rate.sleep()
        while not self.stateMt.state.armed:               #checking if it is already armed or not
            self.ofb_ctl.setArm()
            rate.sleep()
            print("Arming!!")
        while not self.stateMt.state.mode=="OFFBOARD":
            self.ofb_ctl.offboard_set_mode()
            rate.sleep()
            print ("OFFBOARD mode being activated")

    #to stop the Drone it will reduce drone x y speed to 0
    def stopTheDrone(self):
        vel=Twist()
        vel.linear.x = 0
        vel.linear.y = 0
        vel.linear.z = 0
        rate = rospy.Rate(20.0)

        self.local_vel_pub.publish(vel)
        while not rospy.is_shutdown():
            rate.sleep()
            if abs(self.stateMt.velX)<0.1 and abs(self.stateMt.velY)<0.1:
                break
        return

    #to hover above the box at 3m height
    # and if drone position is not above the box it will reach their
    def onSpot(self):
        gainX=0
        gainY=0
        errorX=0
        errorY=0

        vel = Twist()
        rate = rospy.Rate(40.0)
        
        print(self.droneName , "on spot is activated ", self.stateMt.gX,self.stateMt.gY)

        notVCount = 0 
        stopX,stopY = False,False
        while  not rospy.is_shutdown():
            errorX= self.stateMt.pixelErrorX         #pixel error between x center of camera and aruco 
            errorY=self.stateMt.pixelErrorY          #number of pixels between y center of camera and aruco
                                                       
            #if drone stops lately and ArucoMarker become our of range
            if not self.stateMt.isArucoMarkerVisible :
                rate.sleep()
                if not self.stateMt.isArucoMarkerVisible :
                    notVCount += 1 
                    if notVCount > 50:
                        notVCount = 0
                        print("Aruco Not Visible" , self.droneName)
                        self.goToPoint(self.firstDetected)             #it will go to location where Aruco was detected in first place
                else:
                    notVCount = 0

            #calculating gains
            # error goes below 20 it will not change further
            if abs(errorX) < 80 or stopX: #40
                gainX=0
                stopX = True
            else:
                gainX=0.007
            if abs(errorY) < 80 or stopY: #40
                gainY=0
                stopY = True
            else:
                gainY=0.007
            vel.linear.x , vel.linear.y , vel.linear.z = errorX*gainX,errorY*gainY,0

            #velocity should not exceed than 1m/s
            if vel.linear.x > 1:
                vel.linear.x = 1
            elif vel.linear.x < -1:
                vel.linear.x = -1
            if vel.linear.y > 1:
                vel.linear.y = 1
            elif vel.linear.y < -1:
                vel.linear.y = -1

            self.local_vel_pub.publish(vel)      #publishing velocity setpoints
            rate.sleep()
            #now if drone is above aruco is specific range it will procced to land
            if abs(self.stateMt.pixelErrorY) < 90 and abs(self.stateMt.pixelErrorX) < 90 and abs(self.stateMt.velX)<0.05 and abs(self.stateMt.velY)<0.05:
                break
            if stopX and stopY :
                self.stopTheDrone()
                break
        print(self.droneName , "on spot done", self.stateMt.gX,self.stateMt.gY)
        
    #this will put drone above the box
    #it doesn't land on Aruco as the position of camera is slightly towards Y (0,0.35)
    #so it just go above Aruco exactly and now it is ready to land and then pickUpBox
    def goAboveAruco(self):
        rate = rospy.Rate(20.0)
        #self.onSpot()                        #to check if drone is in range above the box
        print("\nNow the game begains !!!\n")

        pos=PoseStamped()
        vel = Twist()

        #going down to land
        sideOfSquare = self.stateMt.sideOfSquare
        stopZ = False
        while  not rospy.is_shutdown() :
            
            sideOfSquare = self.stateMt.sideOfSquare
            errorZ= 90-sideOfSquare #for default SDF 
            errorX= self.stateMt.pixelErrorX
            errorY=self.stateMt.pixelErrorY

            #gains
            if sideOfSquare < 50 :
                gainX=0.005/(sideOfSquare/14)
            else:
                gainX=0.005/(sideOfSquare/50)
            if abs(errorX) < 20:
                gainX=0

            if sideOfSquare < 50  :
                gainY=0.005/(sideOfSquare/14)
            else:
                gainY=0.005/(sideOfSquare/50)
            if abs(errorY) < 20:
                gainY=0
            
            
            if abs(errorZ) < 50:
                gainZ= -0.005
            else :
                gainZ= -0.01
            if abs(errorZ) < 15 or stopZ:
                gainZ = 0
                stopZ=True

            vel.linear.x , vel.linear.y , vel.linear.z = errorX*gainX , errorY*gainY , errorZ*gainZ
            if sideOfSquare < 14 and self.stateMt.isArucoMarkerVisible:
                vel.linear.z = -0.5
            
            #print(  self.stateMt.pixelErrorX , self.stateMt.pixelErrorY,"\t", vel.linear.x , vel.linear.y , vel.linear.z)
            self.local_vel_pub.publish(vel)
            rate.sleep()
            
            if abs(self.stateMt.pixelErrorY) < 25 and abs(self.stateMt.pixelErrorX) < 25 and (sideOfSquare >= 75 or stopZ) and abs(self.stateMt.velX)<0.02 and abs(self.stateMt.velY)<0.02:
                print("the way we want!!" , self.droneName)
                break
            
            #if by chance drone lost it's sight then it will go above 1m again
            if (self.stateMt.isGripperCheck and not self.stateMt.isArucoMarkerVisible) or(self.stateMt.positionZ < 0 and not self.stateMt.isArucoMarkerVisible):
                print(self.stateMt.isGripperCheck)
                print(self.stateMt.positionZ)
                print(self.stateMt.isArucoMarkerVisible)

                self.goToPoint((self.stateMt.positionX,self.stateMt.positionY,self.stateMt.positionZ+1))
                continue
                #break
        print( "right now position is :", self.stateMt.gX,self.stateMt.gY,self.stateMt.positionZ )


    #works for local-coordinates only 
    def goToPoint(self, target, absoluteErrorMargin=(0.2,0.2,0.2) , landOnArucoBool=False ):
        tarX,tarY,tarZ=target
        pos=PoseStamped()
        rate = rospy.Rate(20.0)
        pos.pose.position.x, pos.pose.position.y, pos.pose.position.z  = tarX,tarY,tarZ
        currX,currY,currZ=self.stateMt.positionX,self.stateMt.positionY,self.stateMt.positionZ
        
        self.local_pos_pub.publish(pos)
        #rate.sleep()
        abs1,abs2,abs3=absoluteErrorMargin
        #waiting till drone goes in allowable range
        while  not rospy.is_shutdown():
            #if ArucoDetected then this landOnAruco function will be called and we will firstly land on the box
            if not self.stateMt.state.armed or not self.stateMt.state.mode=="OFFBOARD":
                self.armingDrone()
            if landOnArucoBool and self.stateMt.isArucoMarkerVisible :
                self.firstDetected = (self.stateMt.positionX,self.stateMt.positionY,self.stateMt.positionZ)
                print(self.droneName+ " Aruco Detected!! at " ,self.stateMt.gX,self.stateMt.gY,self.stateMt.positionZ)
                self.onSpot()
                print("Drone Stopped")
                self.goAboveAruco()
                return
            currX,currY,currZ=self.stateMt.positionX,self.stateMt.positionY,self.stateMt.positionZ
            if (abs(tarX-currX) < abs1 and abs(tarY-currY) < abs2 and abs(tarZ-currZ)<abs3):
                break
        rate.sleep() 
    def setPointGlobal(self,target, absoluteErrorMargin=(0.2,0.2,0.2) , landOnArucoBool=False):
        tarX=target[0]-self.homepose[0] 
        tarY=target[1]-self.homepose[1]
        tarZ=target[2]
        print(self.droneName," target is : ",  target, "\tcurrent is :",self.stateMt.gX,self.stateMt.gY,self.stateMt.positionZ)
        self.goToPoint((tarX,tarY,tarZ), absoluteErrorMargin,landOnArucoBool)
        pass
    
    def pickUpBox(self):
        backUpX,backUpY = self.stateMt.positionX, self.stateMt.positionY        #,self.stateMt.positionZ
        #drone must be right aboveTheBox from the goAboveBox
        #it should landInOffobard mode
        self.landInOffboard()
        print( "Picking position of :", self.droneName , self.stateMt.gX,self.stateMt.gY,self.stateMt.positionZ )

        #picking up box
        result = self.ofb_ctl.activateGripper(True)
        print("succes to catch gripper : ", self.droneName ,result, type(result.result))
        if not result.result :          #if failed then will go above 3m again and try to land
            print(self.droneName , "will try again!!")
            self.goToPoint((backUpX,backUpY,3))
            self.goToPoint((backUpX,backUpY,3),landOnArucoBool=True)
        #rospy.sleep(0.2)
        self.armingDrone()
        self.setPointGlobal((self.stateMt.gX,self.stateMt.gY,5))        #   taking off drone  !!! If picked up box
    def dropTheBox(self):
        #initial position of Aruco
        corX,corY = self.stateMt.positionX, self.stateMt.positionY

        vel = Twist()
        rate= rospy.Rate(20)
        rate2 = rospy.Rate(2.5)
        velX,velY,velZ=0,0,-0.2
        eX,eY = 0,0
        while not rospy.is_shutdown() :
            #must also land on expected x y co-ordinates
            eX,eY = corX-self.stateMt.positionX , corY-self.stateMt.positionY
            if eX > 0.025:
                velX=eX - 0.01
            else:
                velX=0
            if eY > 0.025:
                velY=eY - 0.01
            else:
                velY=0
            
            velZ = -0.2 #to move downward

            vel.linear.x , vel.linear.y , vel.linear.z = velX,velY,velZ
            self.local_vel_pub.publish(vel)
            rate.sleep()
            if self.stateMt.extended_state.landed_state == 1 or self.stateMt.extended_state.landed_state == 0  :
                print("to pickUp",self.droneName, self.stateMt.extended_state.landed_state , "landed as expected",self.stateMt.gX, self.stateMt.gY,self.stateMt.positionZ  )
                break

            #if vertical velocity goes below this (as expected is -0.2) it will considered as touching the surface and now box is ready to drop
            if self.stateMt.velZ > -0.1:
                rate2.sleep()
                if self.stateMt.velZ > -0.1:
                    # !!!!!!!!!!!!!!! means drone have touched the surface !!!!!!!!!!!!!!!!!
                    break            
        print( "Dropping position of :", self.droneName , self.stateMt.gX,self.stateMt.gY,self.stateMt.positionZ )
        #if self.stateMt.isGripperCheck:
        result = self.ofb_ctl.activateGripper(False)
        print("succes to catch gripper : ", self.droneName ,result)

    #this will LAND drone in offboard mode
    def landInOffboard(self):
        print(self.droneName, "LANDING")
        corX,corY = self.stateMt.positionX, self.stateMt.positionY
        vel = Twist()
        rate= rospy.Rate(20.0)
        r2  = rospy.Rate(2.5)
        velX,velY,velZ=0,0,-0.5
        eX,eY = 0,0
        while not rospy.is_shutdown() :
            eX,eY = corX-self.stateMt.positionX , corY-self.stateMt.positionY
            if eX > 0.025:
                velX=eX - 0.01
            else:
                velX=0
            if eY > 0.025:
                velY=eY - 0.01
            else:
                velY=0

            if self.stateMt.isGripperCheck and not self.stateMt.isArucoMarkerVisible:
                velZ = -0.2
                vel.linear.x , vel.linear.y , vel.linear.z = velX,velY,velZ
                self.local_vel_pub.publish(vel)
                rate.sleep()
                
                #if vertical velocity goes below this (as expected is -0.2) it will considered as touching the surface and now box is ready to drop
                if self.stateMt.velZ > -0.1:
                    r2.sleep()
                    if self.stateMt.velZ > -0.1:
                        # !!!!!!!!!!!!!!! means drone have touched the surface !!!!!!!!!!!!!!!!!
                        break   
                
            else:
                velZ = -0.5
                vel.linear.x , vel.linear.y , vel.linear.z = velX,velY,velZ
                self.local_vel_pub.publish(vel)
                rate.sleep()
            if self.stateMt.extended_state.landed_state == 1 or self.stateMt.extended_state.landed_state == 0  :
                print("to pickUp",self.droneName, self.stateMt.extended_state.landed_state , "landed as expected",self.stateMt.positionX, self.stateMt.positionY,self.stateMt.positionZ  )
                break

            #if no vertical velocity is deteced the it must be landed in wrong place so it will try to land again
            if self.stateMt.velZ > -0.05:
                print("!!!!!!!!!!!!! NOt Landed as expected !!!!!!!!!!!!!!!!!!!!!!!" , self.droneName)
                r2.sleep()
                if self.stateMt.velZ > -0.05:
                    break
        print("to pickUp",self.droneName, self.stateMt.extended_state.landed_state , "landed as expected",self.stateMt.positionX, self.stateMt.positionY,self.stateMt.positionZ  )    
  


#this will control multiple drones parallely
class control_multiple_drone:
    def __init__(self, rows,color, truck_cells, truck_heights, drones=['edrone1','edrone0'], hompose=[(-1,61),(-1,1)]):
        self.rows = rows
        self.rows_color= color
        self.truck_cells = truck_cells
        self.truck_heights = truck_heights

        self.drones = drones
        self.drones_hompose=hompose
        self.drones_object = []
        self.Threads = []                     #will store threads of drones
        
    def closest(self, coXY, droneName):       #this will give closest point where drone can go
        m = 1000
        ans = [0,0]
        color = ''
        count = 0
        minIndex=0
        before = m
        for _ in self.rows:
            before = m
            m = min( ((coXY[0]+1)**2 +(coXY[1]-1-(_-1)*4)**2)**0.5 ,m )
            if m != before:
                ans=[-1,1+(_-1)*4]              #initial point of row e.g.  (-1,17),(-1,15)
                minIndex=count
            before = m
            m = min( ((coXY[0]-60)**2+(coXY[1]-1-(_-1)*4)**2)**0.5 ,m )
            if m != before:
                ans=[60,1+(_-1)*4]              #initial point of row e.g.  (60,17),(60,15)
                minIndex=count
            count += 1
        color = self.rows_color[minIndex]
        del self.rows[minIndex]
        del self.rows_color[minIndex]            #will remove that rows from the rows list as now drone is going to look at that row
        return ans,color
    
    #this will give co-ordinates of truck where box is supoosed to drop
    def dropLocation(self, color):           
        xy = self.truck_cells[color].pop()
        height= self.truck_heights[color]
        return xy,height
    
    #this will create drone objects
    #within this it will check whethers all subscribers are ready so that drone could go in offboard mode
    def createDroneObjects(self):
        self.drones_object.clear()
        droneName=''
        homepose= [0,0]
        for _ in range(len(self.drones)):
            droneName=self.drones[_]
            homepose=self.drones_hompose[_]
            self.drones_object.append( single_drone_control(stateMoniter(droneName,homepose),droneName,homepose,droneName) )
    #this is the main function
    def mainFun(self, edrone):
        rate=rospy.Rate(20.0)
        while len(self.rows) != 0 :         #this all rows are not reached this will keep going
            #going in offboard if it is not in offboard mode
            edrone.armingDrone()
            edrone.setPointGlobal((edrone.stateMt.gX,edrone.stateMt.gY,4))   #takeofff !!!!

            #going to closest starting point of row e.g (-1,17) or (60,17) as row starts and ends at these points
            closest,color = self.closest([edrone.stateMt.gX,edrone.stateMt.gY] , edrone.droneName)
            edrone.setPointGlobal((closest[0],closest[1],4))
            edrone.stopTheDrone()
            edrone.setPointGlobal((closest[0],closest[1],4), absoluteErrorMargin=(0.15,0.15,0.2))
            
            #now drone will start looking for box
            edrone.ofb_ctl.set_parameter('MPC_XY_VEL_MAX',set_param_value_real=5.0)
            if closest[0] == -1:
                edrone.setPointGlobal((60,closest[1],4), landOnArucoBool=True)
            else:
                edrone.setPointGlobal((-1,closest[1],4), landOnArucoBool=True)

            #will land on box and pick it up      !!!!
            edrone.pickUpBox()

            #drone will go to truck to drop the box
            edrone.ofb_ctl.set_parameter('MPC_XY_VEL_MAX',set_param_value_real=10.0)
            xy,height= self.dropLocation(color)
            edrone.setPointGlobal((xy[0],xy[1],4.5))
            edrone.ofb_ctl.set_parameter('MPC_XY_VEL_MAX',set_param_value_real=5.0)
            edrone.setPointGlobal((xy[0],xy[1],1.7+0.5),absoluteErrorMargin=(0.2,0.2,0.3))
            edrone.dropTheBox()

            edrone.ofb_ctl.set_parameter('MPC_XY_VEL_MAX',set_param_value_real=10.0)
        if len(self.rows) == 0:         #if their are no rows left then drones will go back to initial position and land
            edrone.setPointGlobal((edrone.stateMt.gX,edrone.stateMt.gY,4.5))
            edrone.setPointGlobal((edrone.homepose[0],edrone.homepose[1],4))
            edrone.ofb_ctl.setAutoLandMode()
            while not rospy.is_shutdown():
                if edrone.stateMt.extended_state.landed_state == 1 or edrone.stateMt.extended_state.landed_state == 0 :
                    rate.sleep()
                    break
            edrone.ofb_ctl.setArm(False)
    #this will create threads and also start them
    def createThreads(self):
        for _ in self.drones_object:
            t = threading.Thread(target=self.mainFun,args=(_,))
            self.Threads.append(t)
            t.start()

    def executeThreads(self): #currently this is not in use but it can if we want to activate it in this way
        for _ in self.Threads:
            _.start()



def main():
    blue_cells = []
    for __ in [-5.0,-6.2,-7.4]:
        for _ in [13.85,14.7,15.55,16.4]:
            blue_cells.append([_,__])
    red_cells = []
    for __ in [64.75,66.0,67.20]:
        for _ in [56.60,57.45,58.25,59.1]:    
            red_cells.append([_,__])

    
    truck_cells = {'blue':blue_cells, 'red':red_cells}
    truck_heights= {'blue':1.75 , 'red':1.75}
    control_d = control_multiple_drone([5,7,8,13] , ['blue','blue','red','red'], truck_cells, truck_heights)
    control_d.createDroneObjects()
    control_d.createThreads()
    #print(control_d.Threads, len(control_d.Threads)  )
    #print(control_d.rows, len(control_d.rows)  )
    #control_d.executeThreads()
    

    
if __name__ == '__main__':
    try:
        main()
    except rospy.ROSInterruptException:
        print("Errror!!")
        pass



 